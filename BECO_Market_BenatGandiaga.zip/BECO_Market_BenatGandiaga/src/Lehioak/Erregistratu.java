package Lehioak;

import java.util.ArrayList; 

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.xml.sax.XMLReader;

import Objetuak.bezero;


import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
/**
 * BECO Market sisteman erabiltzaile berria erregistratzeko Swing leihoa.
 * Leiho honetan erabiltzaileak bere datuak sar ditzake: izena, abizena, adina, NANa,
 * erabiltzaile izena eta pasahitza.
 *
 * "Erregistratu" botoiak erabiltzailea sortzen du balidazioa egokia bada eta
 * datuak datu-basean gordetzen ditu.
 * "<" botoiak saio-hasierako leihoa berriz irekitzen du.
 *
 * @egilea Beñat Gandiaga
 * @bertsioa 1.0
 * @ikusi Objetuak.bezero
 * @ikusi Lehioak.login
 * @param txtIzena Erabiltzailearen izena sartzeko eremua
 * @param txtAbizena Erabiltzailearen abizena sartzeko eremua
 * @param txtNan Erabiltzailearen NAN-a sartzeko eremua
 * @param txtErabiltzailea Erabiltzaile izena sartzeko eremua
 * @param txtPasahitza Pasahitza sartzeko eremua
 * @param txtErrepikatu Pasahitza errepikatzeko eremua
 * @param spinnerAdina Erabiltzailearen adina sartzeko JSpinner objektua
 * @param btnSartu Erregistro prozesua hasteko botoia
 * @param btnAtzeraJoan Saio-hasierako leihoa irekitzeko botoia
 */
public class Erregistratu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtErabiltzailea;
	private JTextField txtPasahitza;
	private JTextField txtErrepikatu;
	private JTextField txtIzena;
	private JTextField txtAbizena;
	private JTextField txtNan;
	private JLabel lblAdina;

	/**
	 * Lehio hau erabiltzailea berriak erregistratzeko da
	 */
	public Erregistratu() {
		ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
		setTitle("BECO Market - Erregistratu");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 584);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblErregistratu = new JLabel("Erregistratu");
		lblErregistratu.setForeground(new Color(56, 118, 29));
		lblErregistratu.setHorizontalAlignment(SwingConstants.CENTER);
		lblErregistratu.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblErregistratu.setBounds(75, 176, 185, 41);
		contentPane.add(lblErregistratu);

		JLabel lblLogoa = new JLabel("");
		lblLogoa.setIcon(new ImageIcon(Erregistratu.class.getResource("/Irudiak/BECO_Market_Logoa.png")));
		lblLogoa.setBounds(68, -27, 258, 264);
		contentPane.add(lblLogoa);

		txtErabiltzailea = new JTextField();
		txtErabiltzailea.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtErabiltzailea.getText().equals(" Erabiltzailea")) {
					txtErabiltzailea.setText("");
					txtErabiltzailea.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtErabiltzailea.getText().isEmpty()) {
					txtErabiltzailea.setText(" Erabiltzailea");
					txtErabiltzailea.setForeground(Color.gray);
				}
			}
		});
		txtErabiltzailea.setForeground(new Color(56, 118, 29));
		txtErabiltzailea.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtErabiltzailea.setText(" Erabiltzailea");
		txtErabiltzailea.setBounds(10, 329, 316, 41);
		contentPane.add(txtErabiltzailea);
		txtErabiltzailea.setColumns(10);

		txtPasahitza = new JTextField();
		txtPasahitza.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtPasahitza.getText().equals(" Pasahitza")) {
					txtPasahitza.setText("");
					txtPasahitza.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtPasahitza.getText().isEmpty()) {
					txtPasahitza.setText(" Pasahitza");
					txtPasahitza.setForeground(Color.gray);
				}
			}
		});
		txtPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPasahitza.setText(" Pasahitza");
		txtPasahitza.setForeground(new Color(56, 118, 29));
		txtPasahitza.setColumns(10);
		txtPasahitza.setBounds(10, 380, 316, 41);
		contentPane.add(txtPasahitza);

		txtErrepikatu = new JTextField();
		txtErrepikatu.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtErrepikatu.getText().equals(" Errepikatu Pasahitza")) {
					txtErrepikatu.setText("");
					txtErrepikatu.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtErrepikatu.getText().isEmpty()) {
					txtErrepikatu.setText(" Errepikatu Pasahitza");
					txtErrepikatu.setForeground(Color.gray);
				}
			}
		});
		txtErrepikatu.setText(" Errepikatu Pasahitza");
		txtErrepikatu.setForeground(new Color(56, 118, 29));
		txtErrepikatu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtErrepikatu.setColumns(10);
		txtErrepikatu.setBounds(10, 431, 316, 41);
		contentPane.add(txtErrepikatu);

		txtIzena = new JTextField();
		txtIzena.addKeyListener(new java.awt.event.KeyAdapter() {
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        // Aquí aplicas tu código
		        int key = evt.getKeyChar();

		        boolean mayusculas = key >= 65 && key <= 90;
		        boolean minusculas = key >= 97 && key <= 122;
		        boolean espacio = key == 32;

		        if (!(minusculas || mayusculas || espacio)) {
		            evt.consume();  // Descartar el evento si no es letra o espacio
		        }
		    }
		});
		txtIzena.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtIzena.getText().equals(" Izena")) {
					txtIzena.setText("");
					txtIzena.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtIzena.getText().isEmpty()) {
					txtIzena.setText(" Izena");
					txtIzena.setForeground(Color.gray);
				}
			}
		});
		txtIzena.setText(" Izena");
		txtIzena.setForeground(new Color(56, 118, 29));
		txtIzena.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtIzena.setColumns(10);
		txtIzena.setBounds(10, 227, 109, 41);
		contentPane.add(txtIzena);

		txtAbizena = new JTextField();
		txtAbizena.addKeyListener(new java.awt.event.KeyAdapter() {
		    public void keyTyped(java.awt.event.KeyEvent evt) {
		        // Aquí aplicas tu código
		        int key = evt.getKeyChar();

		        boolean mayusculas = key >= 65 && key <= 90;
		        boolean minusculas = key >= 97 && key <= 122;
		        boolean espacio = key == 32;

		        if (!(minusculas || mayusculas || espacio)) {
		            evt.consume();  // Descartar el evento si no es letra o espacio
		        }
		    }
		});
		txtAbizena.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtAbizena.getText().equals(" Abizena")) {
					txtAbizena.setText("");
					txtAbizena.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtAbizena.getText().isEmpty()) {
					txtAbizena.setText(" Abizena");
					txtAbizena.setForeground(Color.gray);
				}
			}
		});
		txtAbizena.setText(" Abizena");
		txtAbizena.setForeground(new Color(56, 118, 29));
		txtAbizena.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAbizena.setColumns(10);
		txtAbizena.setBounds(126, 227, 200, 41);
		contentPane.add(txtAbizena);

		txtNan = new JTextField();
		txtNan.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtNan.getText().equals(" NAN")) {
					txtNan.setText("");
					txtNan.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtNan.getText().isEmpty()) {
					txtNan.setText(" NAN");
					txtNan.setForeground(Color.gray);
				}
			}
		});
		txtNan.setText(" NAN");
		txtNan.setForeground(new Color(56, 118, 29));
		txtNan.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNan.setColumns(10);
		txtNan.setBounds(10, 278, 185, 41);
		contentPane.add(txtNan);

		JSpinner spinnerAdina = new JSpinner();
		spinnerAdina.setForeground(new Color(56, 118, 29));
		spinnerAdina.setModel(new SpinnerNumberModel(0, 0, 99, 1));
		spinnerAdina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		spinnerAdina.setBounds(252, 278, 74, 41);
		contentPane.add(spinnerAdina);

		lblAdina = new JLabel(" Adina:");
		lblAdina.setForeground(new Color(56, 118, 29));
		lblAdina.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAdina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAdina.setBounds(178, 278, 74, 41);
		contentPane.add(lblAdina);

		JPanel panel = new JPanel();
		panel.setBounds(10, 482, 316, 41);
		contentPane.add(panel);
		panel.setLayout(null);

		JButton btnAtzeraJoan = new JButton("<");
		btnAtzeraJoan.setBackground(new Color(56, 118, 29));
		btnAtzeraJoan.setForeground(new Color(255, 255, 255));
		btnAtzeraJoan.setBounds(0, 0, 122, 41);
		panel.add(btnAtzeraJoan);
		btnAtzeraJoan.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JButton btnSartu = new JButton("Erregistratu");
		btnSartu.setBackground(new Color(56, 118, 29));
		btnSartu.setForeground(new Color(255, 255, 255));
		btnSartu.setBounds(132, 0, 184, 41);
		panel.add(btnSartu);
		btnSartu.setFont(new Font("Tahoma", Font.PLAIN, 15));

		btnSartu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				erregistratu(spinnerAdina);
				  bezero nuevoBezero = new bezero(txtNan.getText(), txtIzena.getText(), 
                          txtAbizena.getText(), (Integer)spinnerAdina.getValue(),
                          txtErabiltzailea.getText(), txtPasahitza.getText());
				  gordeBezeroaFitxategian(nuevoBezero);
}
			
		});
		btnAtzeraJoan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login Login = new login();
				Login.setLocationRelativeTo(null);
				Login.setVisible(true);
				dispose();

			}
		});

		SwingUtilities.invokeLater(() -> lblLogoa.requestFocusInWindow());

	}

	/**
	 * Erabiltzaile berri bat erregistratzen du. Pasahitzak egiaztatzen ditu eta
	 * erabiltzailearen informazioa XML fitxategian gorde. Erabiltzailea XML
	 * fitxategian existitzen ez bada, berria gehitzen du.
	 * 
	 * @param spinnerAdina Adina jasotzeko erabiltzen den JSpinner objektua.
	 */
	public void erregistratu(JSpinner spinnerAdina) {
    int adina = (Integer) spinnerAdina.getValue();
    bezero e1 = new bezero(txtNan.getText(), txtIzena.getText(), txtAbizena.getText(),
        adina, txtErabiltzailea.getText(), txtPasahitza.getText());



    // Validación mejorada de campos
    if (txtIzena.getText().trim().equals("Izena") || 
        txtAbizena.getText().trim().equals("Abizena") || 
        txtNan.getText().trim().equals("NAN") ||
        txtErabiltzailea.getText().trim().equals("Erabiltzailea") || 
        txtPasahitza.getText().trim().equals("Pasahitza") ||
        txtErrepikatu.getText().trim().equals("Errepikatu Pasahitza")) {
        JOptionPane.showMessageDialog(null, "Mesedez, bete datu guztiak", "Errorea", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!txtPasahitza.getText().equals(txtErrepikatu.getText())) {
        JOptionPane.showMessageDialog(null, "Pasahitzak ez dira berdinak", "Errorea", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Conexión a la base de datos
    try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "")) {
        konexioa.setAutoCommit(false);

        // Crear tabla si no existe (con la sintaxis corregida)
        String createTableSQL = "CREATE TABLE IF NOT EXISTS bezeroa ("
            + "idBezero int(20) NOT NULL,"
            + "nan VARCHAR(20) NOT NULL,"
            + "izena varchar(30) NOT NULL,"
            + "abizena varchar(30) NOT NULL,"
            + "adina int(10) NOT NULL,"
            + "erabiltzailea varchar(40) NOT NULL,"
            + "pasahitza varchar(30) NOT NULL,"
            + "PRIMARY KEY (idBezero))";
        
        try (Statement st = konexioa.createStatement()) {
            st.executeUpdate(createTableSQL);
        }

        // Verificar si el usuario ya existe
        if (erabiltzaileaExists(e1.getIdBezero()+"", e1.getNan())) {
            JOptionPane.showMessageDialog(null, "Erabiltzaile hau existitzen da, hasi saioa", 
                                       "Errorea", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insertar nuevo usuario
        String sqlBezero = "INSERT INTO bezeroa (idBezero, nan, izena, abizena, adina, pasahitza, erabiltzailea) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmtBezero = konexioa.prepareStatement(sqlBezero)) {
            stmtBezero.setInt(1, e1.getIdBezero());
            stmtBezero.setString(2, e1.getNan());
            stmtBezero.setString(3, e1.getIzena());
            stmtBezero.setString(4, e1.getAbizena());
            stmtBezero.setInt(5, e1.getAdina());
            stmtBezero.setString(6, e1.getPasahitza());
            stmtBezero.setString(7, e1.getErabiltzailea());
            stmtBezero.executeUpdate();
            
            konexioa.commit();
            
            // Redirigir al login después del registro exitoso
            login Login = new login();
            Login.setLocationRelativeTo(null);
            Login.setVisible(true);
            dispose();
        } catch (SQLException e) {
            konexioa.rollback();
            JOptionPane.showMessageDialog(null, "Errorea datu basean: " + e.getMessage(), 
                                       "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Ezin izan da konexioa egin datu basearekin", 
                                   "Errorea", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}




	public boolean erabiltzaileaExists(String erabiltzailea, String nan) {
		String sql = "SELECT * FROM bezeroa WHERE erabiltzailea = ? OR nan = ?";

		try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
				PreparedStatement stmt = konexioa.prepareStatement(sql)) {

			stmt.setString(1, erabiltzailea);
			stmt.setString(2, nan);

			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0; // Si COUNT(*) > 0, significa que el usuario existe
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false; // Si hay error o no encuentra nada, devolvemos false
	}
	public static void gordeBezeroaFitxategian(bezero erabiltzailea) {
	    File fitxategia = new File("erabiltzaileak.dat");
	    ArrayList<bezero> bezero = new ArrayList<>();

	    if (!fitxategia.exists()) {
	        try {
	            fitxategia.createNewFile();
	            // Inicializar con lista vacía
	            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fitxategia))) {
	                oos.writeObject(bezero);
	            }
	        } catch (IOException ex) {
	            JOptionPane.showMessageDialog(null, "Ezin izan da fitxategia sortu: " + ex.getMessage(),
	                                      "Errorea", JOptionPane.ERROR_MESSAGE);
	            return;
	        }
	    }
	    // Leer el contenido actual del archivo
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fitxategia))) {
	    	bezero = (ArrayList<bezero>) ois.readObject();
	    } catch (IOException | ClassNotFoundException ex) {
	        JOptionPane.showMessageDialog(null, "Errorea fitxategia irakurtzean: " + ex.getMessage(),
	                                  "Errorea", JOptionPane.ERROR_MESSAGE);
	        return;
	    }


	    // NAN errepikatuta dagoen egiaztatu
	    for (bezero b : bezero) {
	        if (b.getNan().equalsIgnoreCase(erabiltzailea.getNan())) {
	            JOptionPane.showMessageDialog(null, "Erabiltzaile hori jadanik existitzen da NAN horrekin.",
	                                          "Errorea", JOptionPane.ERROR_MESSAGE);
	            return;
	        }
	    }

	    // Erabiltzailea gehitu eta fitxategian gorde
	    bezero.add(erabiltzailea);
		writeLog(erabiltzailea.getErabiltzailea(), "Erabiltzaile berria sortu du");
	    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fitxategia))) {
	        oos.writeObject(bezero);
	    } catch (IOException ex) {
	        JOptionPane.showMessageDialog(null, "Errorea fitxategian idaztean: " + ex.getMessage(),
	                                      "Errorea", JOptionPane.ERROR_MESSAGE);
	    }
	}
	public static void writeLog(String erabiltzailea, String mezua) {
		try {
			// Logs-en fitxategia irakurri
			File logFitxategia = new File("logs.txt");
			ArrayList<String> logs = new ArrayList<>();

			// Log fitxategia existitzen bada, irakurtzen dugu
			if (logFitxategia.exists()) {
				try (BufferedReader br = new BufferedReader(new FileReader(logFitxategia))) {
					String line;
					while ((line = br.readLine()) != null) {
						logs.add(line); // Fitxategiko lerro guztiak bildu
					}
				}
			}

			// Log-a sortzen dugu nahi dugun moduan, timestamp-a gehituz
			String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
			String LogBerria = "[" + timestamp + "] (" + erabiltzailea + "): " + mezua;

			// Log berria goikaldean gehitzen dugu (posizio 0-an)
			logs.add(0, LogBerria);

			// Idatzi erregistro guztiak berriro fitxategian, berrienak lehenengo
			try (PrintWriter pw = new PrintWriter(new FileWriter(logFitxategia))) {
				for (String log : logs) {
					pw.println(log); // Fitxategian lerro bakoitza idatzi
				}
			}
		} catch (IOException e) {
			// Errorea gertatuz gero, mezua erakusten da
			JOptionPane.showMessageDialog(null, "Ezin izan da log artxiboan idatzi", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}

}


