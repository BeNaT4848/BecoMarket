package Lehioak;

import javax.imageio.ImageIO;  
import javax.persistence.*;
import javax.swing.ImageIcon;



import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import Objetuak.produktua;
public class ProduktuakKargatu {
  
    public static void main(String[] args) {
        // Crear la conexión a la base de datos ObjectDB
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("BECO_Market.odb");
        EntityManager em = emf.createEntityManager();
      
        try {
            em.getTransaction().begin();
          
            // Crear y persistir los productos
            crearProductos(em);
          
            em.getTransaction().commit();
            System.out.println("Base de datos BECO_Market creada exitosamente con los productos.");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Error al crear la base de datos: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
  
    private static void crearProductos(EntityManager em) throws ParseException, IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
       
            // Cargar todas las imágenes usando Files.readAllBytes()
        	String dilistakImg = "src/Irudiak/Dilisitak.jpg";
        	String txitxirioakImg = "src/Irudiak/txitxirioak.jpg";
        	String babarrunakImg = "src/Irudiak/babarrunak.jpeg";
        	String dilistaBerdeakImg = "src/Irudiak/lentejas-riojana.png";
        	String sojaImg = "src/Irudiak/soja-ecobio.jpeg";
        	String azenarioakImg = "src/Irudiak/azenarioa.jpg";
        	String tomateakImg = "src/Irudiak/tomatea.jpg";
        	String kalabazinakImg = "src/Irudiak/kalabazin.jpeg";
        	String porruakImg = "src/Irudiak/porruak.jpg";
        	String ziazerbakImg = "src/Irudiak/ziazerbak.jpg";
        	String sagarraImg = "src/Irudiak/zagarra.jpg";
        	String madariaImg = "src/Irudiak/madaria.jpeg";
        	String platanoaImg = "src/Irudiak/platanoa.jpeg";
        	String meloiaImg = "src/Irudiak/meloia.jpg";
        	String aranakImg = "src/Irudiak/aranak.jpg";
        	String oilaskoImg = "src/Irudiak/oilasko-bularra.jpg";
        	String behiHaragiaImg = "src/Irudiak/baca-filete.jpg";
        	String txerriSolomoaImg = "src/Irudiak/solomo-de-cerdo.jpg";
        	String hanburgesakImg = "src/Irudiak/hambuergesa.jpg";
        	String txorizoaImg = "src/Irudiak/chorizo.jpg";
        	String chocoKrispiImg = "src/Irudiak/choco.jpg";
        	String popsImg = "src/Irudiak/pops.jpeg";
        	String lionImg = "src/Irudiak/Lion.jpg";
        	String cornFlakesImg = "src/Irudiak/corn-flake.png";
        	String trixImg = "src/Irudiak/triks.jpg";


            // Crear productos con sus imágenes
            em.persist(new produktua(1, dilistakImg, "Dilistak", "luengo", 1.2, sdf.parse("25/09/2025"), 1));
            em.persist(new produktua(2, txitxirioakImg, "Txitxirioak", "Gvtarra", 2.57, sdf.parse("01/10/2025"), 1));
            em.persist(new produktua(3, babarrunakImg, "Babarrunak", "Goikoa", 2.43, sdf.parse("25/08/2025"), 1));
            em.persist(new produktua(4, dilistaBerdeakImg, "Dilista berdeak", "Carretilla", 1.57, sdf.parse("20/12/2025"), 1));
            em.persist(new produktua(5, sojaImg, "Soja", "Eco Bio", 2.4, sdf.parse("05/11/2025"), 1));
          
            em.persist(new produktua(6, azenarioakImg, "Azenarioak", "Natura", 2.43, sdf.parse("05/09/2025"), 2));
            em.persist(new produktua(7, tomateakImg, "Tomateak", "Hegoalde", 2.21, sdf.parse("30/07/2025"), 2));
            em.persist(new produktua(8, kalabazinakImg, "Kalabazinak", "BioBaserri", 1.2, sdf.parse("04/10/2025"), 2));
            em.persist(new produktua(9, porruakImg, "Porruak", "BaserriEko", 1.2, sdf.parse("20/09/2025"), 2));
            em.persist(new produktua(10, ziazerbakImg, "Ziazerbak", "Nafarroakoak", 3.8, sdf.parse("01/10/2025"), 2));
          
            em.persist(new produktua(11, sagarraImg, "Sagarra", "EuskoFruit", 2.2, sdf.parse("05/09/2025"), 3));
            em.persist(new produktua(12, madariaImg, "Madaria", "Natura", 1.23, sdf.parse("05/08/2025"), 3));
            em.persist(new produktua(13, platanoaImg, "Platanoa", "Canarias", 1.21, sdf.parse("13/05/2025"), 3));
            em.persist(new produktua(14, meloiaImg, "Meloia", "Bruño", 2.43, sdf.parse("30/12/2025"), 3));
            em.persist(new produktua(15, aranakImg, "Aranak", "Bizkaia", 3.54, sdf.parse("03/11/2025"), 3));
         
            em.persist(new produktua(16, oilaskoImg, "Oilasko bularra", "Urdaibai", 5.42, sdf.parse("03/06/2025"), 4));
            em.persist(new produktua(17, behiHaragiaImg, "Behi haragia", "Basque Meat", 6.12, sdf.parse("06/10/2025"), 4));
            em.persist(new produktua(18, txerriSolomoaImg, "Txerri solomoa", "Goikoa", 6.12, sdf.parse("03/09/2025"), 4));
            em.persist(new produktua(19, hanburgesakImg, "Hanburgesak", "Angus", 5.42, sdf.parse("02/09/2025"), 4));
            em.persist(new produktua(20, txorizoaImg, "Txorizoa", "Orozko", 4.21, sdf.parse("23/08/2025"), 4));
          
            em.persist(new produktua(21, chocoKrispiImg, "Choco Krispi", "Kelloyy", 3.23, sdf.parse("06/10/2025"), 5));
            em.persist(new produktua(22, popsImg, "Pops", "Kelloyy", 4.87, sdf.parse("09/01/2026"), 5));
            em.persist(new produktua(23, lionImg, "Lion", "Nestle", 6.32, sdf.parse("01/09/2025"), 5));
            em.persist(new produktua(24, cornFlakesImg, "Corn Flakes", "Kelloyy", 2.43, sdf.parse("20/08/2025"), 5));
            em.persist(new produktua(25, trixImg, "Trix", "Nestle", 2.43, sdf.parse("01/01/2025"), 5));
      
    }

    /**
     * Convierte un ImageIcon a un array de bytes
     * @param icon ImageIcon a convertir
     * @return array de bytes con la imagen en formato PNG
     * @throws IOException si ocurre un error durante la conversión
     */
    public static byte[] imageToByteArray(ImageIcon icon) throws IOException {
        if (icon == null) {
            throw new IOException("ImageIcon is null");
        }

        // Asegurarse de que la imagen del icono esté completamente cargada
        if (icon.getImageLoadStatus() != MediaTracker.COMPLETE) {
            throw new IOException("ImageIcon did not load properly.");
        }

        // Obtener la imagen y convertirla a un array de bytes directamente desde el ImageIcon
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            // Convertir la imagen del ImageIcon a un BufferedImage
            BufferedImage bufferedImage = new BufferedImage(
                icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_ARGB
            );
            // Dibujar la imagen del icono sobre el BufferedImage
            bufferedImage.createGraphics().drawImage(icon.getImage(), 0, 0, null);

            // Escribir la imagen en el ByteArrayOutputStream
            ImageIO.write(bufferedImage, "png", baos);
            return baos.toByteArray();
        }
    }

}
