package Lehioak;

import java.awt.Color;   
import java.awt.Component;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;

import com.mysql.cj.jdbc.result.ResultSetMetaData;


import Objetuak.bezero;
import Objetuak.eskaera;
import Objetuak.produktua;

/**
 * infoProduktua lehioa bezero bati zuzenduta dago, BECO Market-eko eskaera sisteman eros daitezkeen produktuak ikusteko eta iragazteko.
 * Leiho honek produktuen taula bat bistaratzen du, argazkiekin eta bestelako informazioarekin. Gainera, iragazki bat eta
 * atzera/saioa ixteko botoiak eskaintzen ditu. Produktuak filtratzeko aukera ematen du janariaren ID bidez.
 *
 * Erabiltzailea saioa hasten duenean eta erosketen leihoa irekitzen duenean bistaratzen da leiho hau.
 * Produktuen kopurua ere erakusten da eta iragazkia aplikatuta eguneratzen da.
 *
 * @author Beñat Gandiaga
 * @version 1.0
 * @since 2025-05-19
 *
 * @param bezero Leihoa sortzen denean pasatzen zaion bezero objektua. Bere izena eta abizena agertzen dira, eta bere IDa erabilita eskaerak kudeatzen dira.
 *
 * @see erosketaLehioa
 * @see login
 * @see produktuak
 * @see eskaera
 */

public class infoProduktua extends JFrame implements ActionListener {
  
    private bezero bezero;
    private JPanel contentPane;
    private JButton btnSaioaItxi;
    private JLabel lblUserInfo;
    private JLabel lblTitle;
    private JPanel panelProduktuak;
	private DefaultTableModel taulaProduktu;
	private Vector<String> columnas;
	private Vector<Vector<String>> datosTabla;
	private JTable erakeraTaula;
	private JTextField textProduktuKantitatea;
	private JTextField textFiltratu;
	private TableRowSorter<DefaultTableModel> Filtratzeko_era;
	private   TypedQuery<produktua> tipoJanari;
	private List<produktua> results2;
	private int indexJanaria = 0;
	
	
    public infoProduktua(bezero bezero) {
    	setIconImage(Toolkit.getDefaultToolkit().getImage(eskaeraLehioa.class.getResource("/Irudiak/BECO_Market_Logoa.png")));
        this.bezero = bezero;
        getContentPane().setLayout(null); // Usamos Absolute Layout
    	
        initializeUI();
    
        setupComponents();
        //cargen datos tabla llamas al contrsuct de eskaera y luego a de bezero para saber que idBezero poner
        eskaera esk = new eskaera();
        esk.setIdBezero(bezero.getIdBezero()); // Asumiendo que tienes este método
        taula();
    
    }
  
    private void initializeUI() {
    	ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
        setTitle("BECO Market - Erosketak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
      
        contentPane = new JPanel();
        contentPane.setLayout(null); // Absolute Layout
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(240, 240, 240));
        setContentPane(contentPane);
    }
  
    private void setupComponents() {
        // Panel superior con información del usuario
        JPanel topPanel = new JPanel();
        topPanel.setLayout(null);
        topPanel.setBounds(10, 10, 800, 64);
        topPanel.setBackground(new Color(56, 118, 29));
        contentPane.add(topPanel);
      
        // Información del usuario
        lblUserInfo = new JLabel("Ongi etorri, " + bezero.getIzena() + " " + bezero.getAbizena());
        lblUserInfo.setBounds(20, 20, 300, 20);
        lblUserInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblUserInfo.setForeground(Color.WHITE);
        topPanel.add(lblUserInfo);
      
        // Título de la aplicación
        lblTitle = new JLabel("BECO Market - Eskaera Sistema");
        lblTitle.setBounds(331, 19, 315, 20);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(lblTitle);
        
        JLabel lblArgazkia = new JLabel("");
        lblArgazkia.setIcon(new ImageIcon(erosketaLehioa.class.getResource("/Irudiak/Carrito.png")));
        lblArgazkia.setBounds(656, 0, 113, 60);
        topPanel.add(lblArgazkia);
      
        // Panel de opción 1: Ver productos
        panelProduktuak = new JPanel();
        panelProduktuak.setLayout(null);
        panelProduktuak.setBounds(10, 73, 766, 399);
        panelProduktuak.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panelProduktuak.setBackground(Color.WHITE);
        panelProduktuak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(panelProduktuak);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane.setBounds(26, 85, 716, 304);
        panelProduktuak.add(scrollPane);
        
        datosTabla = new Vector<>();
        
        columnas = new Vector<String>(); // Definimos las columnas de la tabla
 
        columnas.add("idProduktua");
        columnas.add("idJanaria");
        columnas.add("Argazkia");
        columnas.add("IZENA");
        columnas.add("MARKA");
        columnas.add("Prezioa");
        columnas.add("DATA");
    
     
     // Creo el DefaultTableModel para la tabla, utilizando los datos y las columnas
        taulaProduktu = new DefaultTableModel(datosTabla, columnas) {
     		    // Sobrescribo el método isCellEditable para que las celdas no sean editables
     		    @Override
     		    public boolean isCellEditable(int row, int column) {
     		        return false;  // No se pueden editar las celdas
     		        // Si quieres permitir editar una fila específica, puedes hacerlo con:
     		        // return column == el número de la fila
     		    }
     		};
     	   datosTabla = new Vector<Vector<String>>(); // Inicializamos el vector de datos
     	   
     	// En setupComponents(), después de crear el DefaultTableModel:
     	  erakeraTaula = new JTable(taulaProduktu);
     	  erakeraTaula.setForeground(new Color(56, 118, 29));
     	  erakeraTaula.setFont(new Font("Tahoma", Font.BOLD, 13));
     		scrollPane.setViewportView(erakeraTaula); // Asignar la tabla al JScrollPane
     		
     	

     		// Ajustar alto de filas
     		erakeraTaula.setRowHeight(50);


     		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
     		    @Override
     		    public Component getTableCellRendererComponent(JTable table, Object value, 
     		            boolean isSelected, boolean hasFocus, int row, int column) {

     		        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
     		        setIcon(null);  // Limpia iconos previos por seguridad

     		        String colName = table.getColumnName(column);

     		        if (colName.equals("Argazkia")) {
     		            setText("");

     		            if (value instanceof String && !((String) value).isEmpty()) {
     		                String rutaImagen = (String) value;
     		                try {
     		                    ImageIcon icon;

     		                    if (rutaImagen.startsWith("/")) {
     		                        icon = new ImageIcon(getClass().getResource(rutaImagen));
     		                    } else {
     		                        icon = new ImageIcon(rutaImagen);
     		                    }

     		                    if (icon.getImageLoadStatus() == MediaTracker.COMPLETE) {
     		                        Image img = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
     		                        setIcon(new ImageIcon(img));
     		                    } else {
     		                        setText("Imagen no cargada");
     		                    }
     		                } catch (Exception e) {
     		                    System.err.println("Error al cargar imagen: " + rutaImagen);
     		                    setText("Error");
     		                }
     		            } else {
     		                setText("Sin imagen");
     		            }

     		            setHorizontalAlignment(CENTER);
     		        } else {
     		            // Para otras columnas, centramos el texto
     		            setIcon(null);
     		            setHorizontalAlignment(SwingConstants.CENTER);
     		        }

     		        return this;
     		    }
     		};

     		// Aplicamos el renderizador a todas las columnas (Object.class)
     		erakeraTaula.setDefaultRenderer(Object.class, renderer);



     		// Para que los cambios tengan efecto
     		erakeraTaula.revalidate();
     		erakeraTaula.repaint();
     // En el método setupComponents(), después de crear la tabla JTable:
     	// Ajustar el ancho de columnas "IZENA" y "MARKA"
     	
   
     		erakeraTaula.getTableHeader().setForeground(new Color(255, 255, 255));
     		erakeraTaula.getTableHeader().setBackground(new Color(56, 118, 29));
     		
     	        textFiltratu = new JTextField();
     	        textFiltratu.setForeground(new Color(56, 118, 29));
     	        textFiltratu.setHorizontalAlignment(SwingConstants.CENTER);
     	        textFiltratu.setFont(new Font("Tahoma", Font.BOLD, 26));
     	        textFiltratu.setBounds(37, 31, 161, 38);
     	        panelProduktuak.add(textFiltratu);
     	        textFiltratu.setColumns(10);
     	        
     	      
     	        
     	 	  erakeraTaula.addMouseListener(new MouseAdapter() {
   				@Override
   				public void mouseClicked(MouseEvent e) {
   					int errenkada;
   				
   					errenkada = erakeraTaula.getSelectedRow();
   					String id = (String) erakeraTaula.getValueAt(errenkada, 1);
   					textFiltratu.setText(id);
   				
   				}
   			});
     	        
     	        erakeraTaula.setAutoCreateRowSorter(true);
     	       Filtratzeko_era = new TableRowSorter<>(taulaProduktu);
      	      erakeraTaula.setRowSorter(Filtratzeko_era);
      	      
      	    JButton btnFiltratu = new JButton("Filtratu");
      	    btnFiltratu.setBackground(new Color(226, 226, 226));
      	    btnFiltratu.setForeground(new Color(56, 118, 29));
 	        btnFiltratu.setFont(new Font("Tahoma", Font.BOLD, 18));
 	        btnFiltratu.setBounds(219, 34, 116, 38);
 	        
 	    
 	       btnFiltratu.addActionListener(new ActionListener() {
 	            public void actionPerformed(ActionEvent e) {
 	                // Filtra las filas por el texto escrito
 	                String filtroa = textFiltratu.getText();
 	                Filtratzeko_era.setRowFilter(RowFilter.regexFilter(filtroa, 1));
 	                actualizarTotales(); // Actualiza los valores de jugadores y sueldos después de filtrar
 	            }
 	        });
 	    
 	      panelProduktuak.add(btnFiltratu);
 	    
 	  
 	 
 	 

        btnSaioaItxi = new JButton("Saioa Itxi");
        btnSaioaItxi.setForeground(new Color(255, 255, 255));
        btnSaioaItxi.setBackground(new Color(56, 118, 29));
        btnSaioaItxi.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnSaioaItxi.setBounds(10, 499, 133, 40);
        btnSaioaItxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login login = new login();
				login.setLocationRelativeTo(null);
				login.setVisible(true);
				dispose();
			}
		});
        contentPane.add(btnSaioaItxi);
        
        JButton btnAtzera = new JButton("Atzera");
        btnAtzera.setForeground(new Color(255, 255, 255));
        btnAtzera.setBackground(new Color(56, 118, 29));
        btnAtzera.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		erosketaLehioa erosi = new erosketaLehioa(bezero);
        		erosi.setLocationRelativeTo(null);
        		erosi.setVisible(true);
				dispose();
        	}
        });
        btnAtzera.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnAtzera.setBounds(166, 499, 100, 40);
        contentPane.add(btnAtzera);
        
        JLabel lblProduktuKantitatea = new JLabel("Produktu Kantitatea");
        lblProduktuKantitatea.setBounds(384, 500, 191, 35);
        contentPane.add(lblProduktuKantitatea);
        lblProduktuKantitatea.setForeground(new Color(0, 128, 0));
        lblProduktuKantitatea.setFont(new Font("Tahoma", Font.BOLD, 18));
        
        textProduktuKantitatea = new JTextField();
        textProduktuKantitatea.setBounds(615, 505, 96, 27);
        contentPane.add(textProduktuKantitatea);
        textProduktuKantitatea.setEnabled(false);
        textProduktuKantitatea.setEditable(false);
        textProduktuKantitatea.setText("0");
        textProduktuKantitatea.setHorizontalAlignment(SwingConstants.CENTER);
        textProduktuKantitatea.setForeground(new Color(0, 128, 0));
        textProduktuKantitatea.setFont(new Font("Tahoma", Font.BOLD, 16));
        textProduktuKantitatea.setColumns(10);
        
        
        // 1. Primero creamos el renderer por defecto centrado
 	  
		
    }
  
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
        	
         
            login frame = new login();
        	frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
    public void taula() {
        datosTabla.clear();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("C:\\Users\\ik_1dw3d\\eclipse-workspace\\BECO_Market_BenatGandiaga\\BECO_Market.odb");
        EntityManager em = emf.createEntityManager();
        TypedQuery<produktua> tq = em.createQuery("SELECT j FROM produktua j", produktua.class);
        results2 =  tq.getResultList();
        results2.sort(null);
        for (produktua j : results2) {
            Vector<String> fila = new Vector<String>();
           // System.out.println("Cargando producto: " + j.getIzena());
            // Agrega los datos
        
            fila.add(String.valueOf(j.getProduktuKodea())); // Producto Kodea
            fila.add(String.valueOf(j.getIdJanaria())); // ID Janaria (o el nombre adecuado)
            // Obtener la ruta de la imagen y convertir a bytes si es necesario
            // Obtener bytes de la imagen
            // Manejo de la imagen
            fila.add(procesarRutaImagen(j));
            fila.add(String.valueOf(j.getIzena()));
            fila.add(String.valueOf(j.getMarka()));
            fila.add(String.valueOf(j.getPrezioa())); // Precio (suponiendo que es numérico)
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            fila.add(j.getData() != null ? sdf.format(j.getData()) : ""); // Fecha
            
            // Agregar la fila a los datos de la tabla
            datosTabla.add(fila);
            
        }
        em.close();
        emf.close();

        taulaProduktu.setDataVector(datosTabla, columnas);
        TableColumnModel columnModel = erakeraTaula.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(50); 
        columnModel.getColumn(1).setPreferredWidth(50); 
        columnModel.getColumn(3).setPreferredWidth(100); // IZENA
        columnModel.getColumn(4).setPreferredWidth(100); // MARKA
     
       Filtratzeko_era = new TableRowSorter<>(taulaProduktu);
        erakeraTaula.setRowSorter(Filtratzeko_era);
      
    
        
        actualizarTotales();
    }

    // ============================
    // Método para borrar un jugador
    // ============================
  
	

	 
	   public void actualizarTotales() {
	        int size = erakeraTaula.getRowCount();
	        
	        
	        
	        textProduktuKantitatea.setText("" + size);
	      
	   }
	
	   private String procesarRutaImagen(produktua produktua) {
		    String rutaImagen = produktua.getArgazkiaa();
		    
		    if (rutaImagen == null || rutaImagen.trim().isEmpty()) {
		        return "[SIN IMAGEN]";
		    }
		    
		    // Verificar si la ruta es absoluta y el archivo existe
		    if (new File(rutaImagen).exists()) {
		        return rutaImagen;
		    }
		    
		    // Verificar si la ruta es relativa a recursos
		    if (rutaImagen.startsWith("/")) {
		        if (getClass().getResource(rutaImagen) != null) {
		            return rutaImagen;
		        }
		    } else {
		        // Si no empieza con /, asumimos que es relativa a la carpeta Irudiak
		        String rutaRelativa = "/Irudiak/" + rutaImagen;
		        if (getClass().getResource(rutaRelativa) != null) {
		            return rutaRelativa;
		        }
		    }
		    
		    return "[IMAGEN NO ENCONTRADA]";
		}
	
		@Override
		public void actionPerformed(ActionEvent ae) {
			// ze elementutan eman den akzioa jasotzen dogu.
			Object o = ae.getSource();
		
			}
			
			
	
}



