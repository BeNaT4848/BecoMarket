package Lehioak;


import javax.swing.*;   
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.mysql.cj.jdbc.result.ResultSetMetaData;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import Objetuak.Data;
import Objetuak.bezero;
import Objetuak.eskaera;
import Objetuak.janaria;
import Objetuak.produktua;
import Lehioak.login;
import Lehioak.eskaeraLehioa;
import Lehioak.infoProduktua;
/**
 * BECO Market sistemako erosketak egiteko eta produktuak kudeatzeko leiho nagusia.
 * 
 * <p>Interfaze grafiko honek honako aukerak ematen ditu:</p>
 * <ul>
 *   <li>Produktuen katalogoa ikustea eta erostea</li>
 *   <li>Produktuen datak eguneratzea (administratzaileentzat)</li>
 *   <li>Erosketen historia ikustea</li>
 *   <li>Datu-baseko informazioa XML formatuan esportatzea</li>
 * </ul>
 * 
 * @see Objetuak.bezero
 * @see Objetuak.janaria
 * @see Objetuak.produktua
 * @see Lehioak.login
 * @see Lehioak.eskaeraLehioa
 * @see Lehioak.infoProduktua
 * 
 * @since 1.0
 */
public class erosketaLehioa extends JFrame {
  
    private bezero bezero;
    private JPanel contentPane;
    private JButton btnSaioaItxi;
    private JButton btnEskaerakIkusi;
    private JLabel lblUserInfo;
    private JLabel lblTitle;
    private JPanel panelProduktuak;
	private DefaultTableModel taulaProduktu;
    private JTextField textKantitatea;
    private JComboBox<janaria> cmbJanaria; 
    private DefaultComboBoxModel<janaria> equipoModel;
	private Vector<String> columnas;
	private Vector<Vector<String>> datosTabla;
	private JTable taula;
	private JTextField txtEguna;
	private JTextField textHilabetea;
	private JTextField textUrtea;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private int currentJanariaIndex = 0;
	private int totalJanariak = 0;
	private    JLabel lblJanariaProduktuak;
	/**
     * Erosketa leihoaren eraikitzailea.
     * 
     * @param bezero Saioa hasi duen erabiltzailearen datuak dituen objektua
     * @see Objetuak.bezero
     */
	
    public erosketaLehioa(bezero bezero) {
        this.bezero = bezero;
        getContentPane().setLayout(null); // Usamos Absolute Layout
    	
        initializeUI();
    
        setupComponents();
      
    }
  
    private void initializeUI() {
    	ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
	
        setTitle("BECO Market - Erosketak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
      
        contentPane = new JPanel();
        contentPane.setLayout(null); // Absolute Layout
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(240, 240, 240));
        setContentPane(contentPane);
    }
    /**
     * Interfaze grafikoa oinarrizko konfigurazioekin hasieratzen du.
     */
    private void setupComponents() {
        // Panel superior con información del usuario
        JPanel topPanel = new JPanel();
        topPanel.setLayout(null);
        topPanel.setBounds(0, 0, 800, 60);
        topPanel.setBackground(new Color(56, 118, 29));
        contentPane.add(topPanel);
      
        // Información del usuario
        lblUserInfo = new JLabel("Ongi etorri, " + bezero.getIzena() + " " + bezero.getAbizena());
        lblUserInfo.setBounds(20, 20, 300, 20);
        lblUserInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblUserInfo.setForeground(Color.WHITE);
        topPanel.add(lblUserInfo);
      
        // Título de la aplicación
        lblTitle = new JLabel("BECO Market - Erosketa Sistema");
        lblTitle.setBounds(331, 19, 315, 20);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(lblTitle);
        
        JLabel lblArgazkia = new JLabel("");
        lblArgazkia.setIcon(new ImageIcon(erosketaLehioa.class.getResource("/Irudiak/Carrito.png")));
        lblArgazkia.setBounds(656, 0, 113, 60);
        topPanel.add(lblArgazkia);
      
        // Panel de opción 1: Ver productos
        panelProduktuak = new JPanel();
        panelProduktuak.setLayout(null);
        panelProduktuak.setBounds(10, 73, 766, 399);
        panelProduktuak.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panelProduktuak.setBackground(Color.WHITE);
        panelProduktuak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(panelProduktuak);
        
        JScrollPane scrollPane = new JScrollPane();
        	if (bezero.getPasahitza().equals("admin123")) {
        scrollPane.setBounds(10, 124, 728, 223);
    	 }
         if (!bezero.getPasahitza().equals("admin123")) {
        scrollPane.setBounds(10, 124, 518, 223);
         }
        panelProduktuak.add(scrollPane);
        
        columnas = new Vector<String>(); // Definimos las columnas de la tabla
        columnas.add("produktuKodea");
        columnas.add("Argazkia");
        columnas.add("Izena");
        columnas.add("Marka");
        columnas.add("Prezioa");
        columnas.add("Data");
        columnas.add("idJanaria");

     
        datosTabla = new Vector<Vector<String>>(); // Inicializamos el vector de datos
     
     // Creo el DefaultTableModel para la tabla, utilizando los datos y las columnas
        taulaProduktu = new DefaultTableModel(datosTabla, columnas) {
     		    // Sobrescribo el método isCellEditable para que las celdas no sean editables
     		    @Override
     		    public boolean isCellEditable(int row, int column) {
     		        return false;  // No se pueden editar las celdas
     		        // Si quieres permitir editar una fila específica, puedes hacerlo con:
     		        // return column == el número de la fila
     		    }
     		};
     	
     	   
     	// En setupComponents(), después de crear el DefaultTableModel:
     	  taula = new JTable(taulaProduktu);
     	  taula.setForeground(new Color(56, 118, 29));
     	  taula.setFont(new Font("Tahoma", Font.PLAIN, 12));
     		scrollPane.setViewportView(taula); // Asignar la tabla al JScrollPane
     		
     

     		// Ajustar alto de filas
     		taula.setRowHeight(40);


     		// Configurar márgenes internos
     		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
     		    @Override
     		    public Component getTableCellRendererComponent(JTable table, Object value, 
     		            boolean isSelected, boolean hasFocus, int row, int column) {
     		        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
     		        setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
     		        return this;
     		    }
     		};


     		for (int i = 0; i < taula.getColumnCount(); i++) {
     		    taula.getColumnModel().getColumn(i).setCellRenderer(renderer);
     		}


     		// Para que los cambios tengan efecto
     		taula.revalidate();
     		taula.repaint();



     		taula.getTableHeader().setForeground(new Color(255, 255, 255));
     		taula.getTableHeader().setBackground(new Color(56, 118, 29));
     	    
     		if (!bezero.getPasahitza().equals("admin123")) {
        JButton btnGordeProduktua = new JButton("Gorde");
        btnGordeProduktua.setForeground(new Color(56, 118, 19));
        btnGordeProduktua.setBackground(new Color(226, 226, 226));
        btnGordeProduktua.setFont(new Font("Tahoma", Font.BOLD, 20));
     // 2. Configurar los botones + y -
     // En el método setupComponents(), modificar el ActionListener del botón "Gorde":
        btnGordeProduktua.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarProducto();
            }
        });
        btnGordeProduktua.setBounds(567, 312, 159, 56);
        panelProduktuak.add(btnGordeProduktua);
        
        textKantitatea = new JTextField();
        textKantitatea.setForeground(new Color(56, 118, 19));
        textKantitatea.setText("0");
        textKantitatea.setHorizontalAlignment(SwingConstants.CENTER);
        textKantitatea.setFont(new Font("Tahoma", Font.BOLD, 24));
        textKantitatea.setBounds(565, 223, 161, 47);
        panelProduktuak.add(textKantitatea);
        textKantitatea.setColumns(10);
     		}
     // En el método setupComponents(), después de crear la tabla JTable:
        taula.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            	
                int filaSeleccionada = taula.getSelectedRow();
                
                if (filaSeleccionada >= 0) {
                	if (!bezero.getPasahitza().equals("admin123")) {
                    // Siempre poner "1" al seleccionar
                    textKantitatea.setText("1");
                	}
                    // Obtener y dividir la fecha
                	if (bezero.getPasahitza().equals("admin123")) {
                		
                    String fechaStr = taula.getValueAt(filaSeleccionada, 5).toString(); // Asume columna 6 es fecha
                    Data data = new Data(fechaStr);
                    
                    txtEguna.setText(String.valueOf(data.getDia()));
                    textHilabetea.setText(String.valueOf(data.getHila()));
                    textUrtea.setText(String.valueOf(data.getUrtea()));
                }
            }
            }
        });
        taula.setAutoCreateRowSorter(true);
        
    	if (bezero.getPasahitza().equals("admin123")) {
        JButton btnLehenengo = new JButton("<<");
        btnLehenengo.setForeground(new Color(56, 118, 29));
        btnLehenengo.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnLehenengo.setBackground(new Color(226, 226, 226));
        btnLehenengo.setActionCommand("lehena");
        btnLehenengo.setBounds(435, 36, 62, 36);
        btnLehenengo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iralaPrimerElemento();
            }
        });
        panelProduktuak.add(btnLehenengo);
        
        JButton btnAtzereJanaria = new JButton("<");
        btnAtzereJanaria.setForeground(new Color(56, 118, 29));
        btnAtzereJanaria.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnAtzereJanaria.setBackground(new Color(226, 226, 226));
        btnAtzereJanaria.setActionCommand("aurrekoa");
        btnAtzereJanaria.setBounds(504, 36, 51, 36);
        btnAtzereJanaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iralaElementoAnterior();
            }
        });
        panelProduktuak.add(btnAtzereJanaria);
        
        JButton btnUrrengoJanaria = new JButton(">");
   
        btnUrrengoJanaria.setForeground(new Color(56, 118, 29));
        btnUrrengoJanaria.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnUrrengoJanaria.setBackground(new Color(226, 226, 226));
        btnUrrengoJanaria.setActionCommand("hurrengoa");
        btnUrrengoJanaria.setBounds(633, 36, 51, 36);
        btnUrrengoJanaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iralaElementoSiguiente();
            }
        });
        panelProduktuak.add(btnUrrengoJanaria);
        
        JButton btnAzkena = new JButton(">>");
        btnAzkena.setForeground(new Color(56, 118, 29));
        btnAzkena.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnAzkena.setBackground(new Color(226, 226, 226));
        btnAzkena.setActionCommand("azkena");
        btnAzkena.setBounds(691, 36, 65, 36);
        btnAzkena.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iralaUltimoElemento();
            }
        });
        panelProduktuak.add(btnAzkena);
        
         lblJanariaProduktuak = new JLabel("");
         lblJanariaProduktuak.setFont(new Font("Tahoma", Font.PLAIN, 7));
        lblJanariaProduktuak.setBounds(565, 34, 58, 38);
        lblJanariaProduktuak.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (totalJanariak > 0) {
                    janaria selected = equipoModel.getElementAt(currentJanariaIndex);
                    taula(selected);
                }
            }
        });
    	
        panelProduktuak.add(lblJanariaProduktuak);
    	// Creo y configuro el JComboBox para los equipos
    	}
		equipoModel = new DefaultComboBoxModel<janaria>();
		if (!bezero.getPasahitza().equals("admin123")) {
		cmbJanaria = new JComboBox<janaria>(equipoModel);
		cmbJanaria.setForeground(new Color(56, 118, 19));
		cmbJanaria.setFont(new Font("Tahoma", Font.BOLD, 16));
		cmbJanaria.addItemListener(new ItemListener() {
		    public void itemStateChanged(ItemEvent e) {
		        if (e.getStateChange() == ItemEvent.SELECTED) {
		            janaria selected = (janaria) cmbJanaria.getSelectedItem();
		            taula(selected);
		        }
		    }
		});
		 cmbJanaria.setBounds(538, 29, 218, 47);
	        panelProduktuak.add(cmbJanaria);
	        
    	}
	        
			if (bezero.getPasahitza().equals("admin123")) {
				
	        JLabel lblDATA = new JLabel("DATA");
	        lblDATA.setForeground(new Color(56, 118, 19));
	        lblDATA.setFont(new Font("Tahoma", Font.BOLD, 18));
	        lblDATA.setBounds(27, 36, 85, 33);
	        panelProduktuak.add(lblDATA);
	        
	        txtEguna = new JTextField();
	        txtEguna.setHorizontalAlignment(SwingConstants.CENTER);
	        txtEguna.setForeground(new Color(56, 118, 19));
	        txtEguna.setFont(new Font("Tahoma", Font.BOLD, 16));
	        txtEguna.setBounds(100, 30, 53, 47);
	        panelProduktuak.add(txtEguna);
	        txtEguna.setColumns(10);
	        
	        textHilabetea = new JTextField();
	        textHilabetea.setHorizontalAlignment(SwingConstants.CENTER);
	        textHilabetea.setForeground(new Color(56, 118, 19));
	        textHilabetea.setFont(new Font("Tahoma", Font.BOLD, 16));
	        textHilabetea.setColumns(10);
	        textHilabetea.setBounds(194, 30, 53, 47);
	        panelProduktuak.add(textHilabetea);
	        
	        textUrtea = new JTextField();
	        textUrtea.setHorizontalAlignment(SwingConstants.CENTER);
	        textUrtea.setFont(new Font("Tahoma", Font.BOLD, 16));
	        textUrtea.setForeground(new Color(56, 118, 19));
	        textUrtea.setColumns(10);
	        textUrtea.setBounds(288, 30, 53, 47);
	        panelProduktuak.add(textUrtea);
	        
	        JLabel lblNewLabel = new JLabel("/");
	        lblNewLabel.setForeground(new Color(56, 118, 19));
	        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
	        lblNewLabel.setBounds(163, 10, 21, 80);
	        panelProduktuak.add(lblNewLabel);
	        
	        lblNewLabel_1 = new JLabel("/");
	        lblNewLabel_1.setForeground(new Color(56, 118, 19));
	        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 36));
	        lblNewLabel_1.setBounds(257, 0, 21, 101);
	        panelProduktuak.add(lblNewLabel_1);
	        
	        JButton btnSartuData = new JButton("Sartu");
	        btnSartuData.setBackground(new Color(56, 118, 19));
	        btnSartuData.setForeground(new Color(255, 255, 255));
	        btnSartuData.setFont(new Font("Tahoma", Font.BOLD, 7));
	        btnSartuData.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		dataAldatu();
	        	}
	        });
	        btnSartuData.setBounds(351, 34, 62, 38);
	        panelProduktuak.add(btnSartuData);
			}
			if (!bezero.getPasahitza().equals("admin123")) {
	        lblNewLabel_2 = new JLabel("SARTU KANTITATEA");
	        lblNewLabel_2.setForeground(new Color(56, 118, 19));
	        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        lblNewLabel_2.setBounds(555, 169, 188, 39);
	        panelProduktuak.add(lblNewLabel_2);
	
	        JLabel lblTituloaErab = new JLabel("Produktuen Erosketa");
	        lblTituloaErab.setForeground(new Color(0, 128, 64));
	        lblTituloaErab.setHorizontalAlignment(SwingConstants.CENTER);
	        lblTituloaErab.setFont(new Font("Tahoma", Font.BOLD, 30));
	        lblTituloaErab.setBounds(33, 18, 450, 72);
	        panelProduktuak.add(lblTituloaErab);
	        
	        btnEskaerakIkusi = new JButton("Eskaerak Ikusi");
	        btnEskaerakIkusi.setForeground(new Color(255, 255, 255));
	        btnEskaerakIkusi.setBackground(new Color(56, 118, 19));
	        btnEskaerakIkusi.setFont(new Font("Tahoma", Font.BOLD, 14));
	        btnEskaerakIkusi.setBounds(581, 499, 150, 40);
	        btnEskaerakIkusi.addActionListener(new ActionListener() {
	    			public void actionPerformed(ActionEvent e) {
	    				eskaeraLehioa eskaera = new eskaeraLehioa(bezero);
	    				eskaera.setLocationRelativeTo(null);
	    				eskaera.setVisible(true);
	    				dispose();
	    			}
	    		});
	        contentPane.add(btnEskaerakIkusi);
	    	}
			if (bezero.getPasahitza().equals("admin123")) {
				irakurriJanariakk();
				}
			if (!bezero.getPasahitza().equals("admin123")) {
				irakurriJanaria();
      
			}
        btnSaioaItxi = new JButton("Saioa Itxi");
        btnSaioaItxi.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnSaioaItxi.setForeground(new Color(255, 255, 255));
        btnSaioaItxi.setBackground(new Color(56, 118, 19));
        btnSaioaItxi.setBounds(10, 499, 100, 40);
        btnSaioaItxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login login = new login();
				login.setLocationRelativeTo(null);			
				login.setVisible(true);
			    writeLog(bezero.getErabiltzailea(), "Saioa itxi dau");
				dispose();
			}
		});
        contentPane.add(btnSaioaItxi);
    	if (bezero.getPasahitza().equals("admin123")) {
        JButton btnXmlSortu = new JButton("XML sortu");
        btnXmlSortu.setBackground(new Color(56, 118, 19));
        btnXmlSortu.setForeground(new Color(255, 255, 255));
        btnXmlSortu.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnXmlSortu.setBounds(191, 498, 169, 40);
        btnXmlSortu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Establecer conexión con la base de datos
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beco_market", "root", "");
                    
                    // Crear documento XML
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document doc = builder.newDocument();

                    // Crear elemento raíz
                    Element root = doc.createElement("beco_market");
                    doc.appendChild(root);

                    // 1. Sección BEZEROAK (clientes)
                    Element bezeroak = doc.createElement("bezeroak");
                    root.appendChild(bezeroak);
                    
                 // Crear elemento principal (principa)
                    Element principa = doc.createElement("erabiltzaileak");
                    bezeroak.appendChild(principa);

                    
                    // Obtener todos los usuarios
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM bezeroa");
                    ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
                 
                    while (rs.next()) {
                        // Para cada usuario, crear un elemento erabiltzailea dentro de principa
                        Element erabiltzailea = doc.createElement("erabiltzailea");
                        principa.appendChild(erabiltzailea);
                        
                        // Recorrer todas las columnas de la tabla "erabiltzailea"
                        for (int i = 1; i <= metaData.getColumnCount(); i++) {
                            String columnName = metaData.getColumnName(i);
                            String value = rs.getString(i);
                            
                            Element field = doc.createElement(columnName);
                            field.appendChild(doc.createTextNode(value != null ? value : ""));
                            erabiltzailea.appendChild(field);
                        }
                    }

                    // 2. Sección JANARIAK (tipos de comida) con sus PRODUCTOS
                    Element janariak = doc.createElement("janariak");
                    root.appendChild(janariak);
                    
                    // Primero obtener todos los tipos de comida
                    rs = st.executeQuery("SELECT * FROM janaria");
                    
                    while (rs.next()) {
                        int idJanaria = rs.getInt("idJanaria");
                        String mota = rs.getString("mota");
                        
                        // Crear elemento para este tipo de comida
                        Element janaria = doc.createElement("janaria");
                        janariak.appendChild(janaria);
                        
                        // Añadir datos básicos del tipo de comida
                        Element idElement = doc.createElement("idJanaria");
                        idElement.appendChild(doc.createTextNode(String.valueOf(idJanaria)));
                        janaria.appendChild(idElement);
                        
                        Element motaElement = doc.createElement("mota");
                        motaElement.appendChild(doc.createTextNode(mota));
                        janaria.appendChild(motaElement);
                        
                        // Obtener todos los productos de este tipo de comida
                        Element produktuak = doc.createElement("produktuak");
                        janaria.appendChild(produktuak);
                        
                        PreparedStatement pst = conn.prepareStatement(
                            "SELECT * FROM produktuak WHERE idJanaria = ?");
                        pst.setInt(1, idJanaria);
                        
                        ResultSet rsProduktuak = pst.executeQuery();
                        ResultSetMetaData produktuMetaData = (ResultSetMetaData) rsProduktuak.getMetaData();
                        
                        while (rsProduktuak.next()) {
                            Element produktua = doc.createElement("produktua");
                            produktuak.appendChild(produktua);
                            
                            for (int i = 1; i <= produktuMetaData.getColumnCount(); i++) {
                                String columnName = produktuMetaData.getColumnName(i);
                                // No incluir la imagen en el XML
                                if (!columnName.equalsIgnoreCase("argazkia")) {
                                    String value = rsProduktuak.getString(i);
                                    
                                    Element field = doc.createElement(columnName);
                                    field.appendChild(doc.createTextNode(value != null ? value : ""));
                                    produktua.appendChild(field);
                                }
                            }
                        }
                        rsProduktuak.close();
                        pst.close();
                    }

                    // Guardar el documento XML
                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                    Transformer transformer = transformerFactory.newTransformer();
                    
                    // Configurar formato del XML
                    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
                    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                    
                    DOMSource source = new DOMSource(doc);
                    
                    // Guardar en el directorio del proyecto
                    File file = new File("beco_market_data.xml");
                    StreamResult result = new StreamResult(file);
                    
                    transformer.transform(source, result);
                    
                    // Cerrar recursos
                    rs.close();
                    st.close();
                    conn.close();
                    
                    JOptionPane.showMessageDialog(null, 
                        "XML fitxategia ondo sortu da: " + file.getAbsolutePath(), 
                        "XML Sortua", 
                        JOptionPane.INFORMATION_MESSAGE);
                    writeLog(bezero.getErabiltzailea(), "XML-a sortu dau");
                    
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, 
                        "Errorea XML fitxategia sortzerakoan: " + ex.getMessage(), 
                        "Errorea", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        contentPane.add(btnXmlSortu);
        
        JButton btnProduktuakIkusi = new JButton("Produktuak");
        btnProduktuakIkusi.setBackground(new Color(56, 118, 19));
        btnProduktuakIkusi.setForeground(new Color(255, 255, 255));
        btnProduktuakIkusi.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnProduktuakIkusi.setBounds(612, 499, 129, 40);
        btnProduktuakIkusi.addActionListener(new ActionListener() {
     			public void actionPerformed(ActionEvent e) {
     				infoProduktua infoProduktu = new infoProduktua(bezero);
     				infoProduktu.setLocationRelativeTo(null);
     				infoProduktu.setVisible(true);
     				dispose();
     			}
     		});
        contentPane.add(btnProduktuakIkusi);
        
        JButton btnErabiltzaileak = new JButton("Erabiltzaileak");
        btnErabiltzaileak.setForeground(Color.WHITE);
        btnErabiltzaileak.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnErabiltzaileak.setBackground(new Color(56, 118, 19));
        btnErabiltzaileak.setBounds(402, 499, 169, 40);
        btnErabiltzaileak.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent e) {
 				erabiltzaileLehioa erabLehioa = new erabiltzaileLehioa(bezero);
 				erabLehioa.setLocationRelativeTo(null);
 				erabLehioa.setVisible(true);
 				dispose();
 			}
 		});
        contentPane.add(btnErabiltzaileak);
    	}
		  // 1. Primero creamos el renderer por defecto centrado
 	    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
 	    centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
 	    
 	    // 2. Aplicamos el renderer centrado a TODAS las columnas
 	    for (int i = 0; i < taula.getColumnCount(); i++) {
 	        taula.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
 	    }
 	    
 	    // 3. Luego SOBREESCRIBIMOS solo la columna de imágenes con su renderer especial
 	   taula.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());
    }
  
    /**
     * Ikusizko osagai guztiak konfiguratu eta kokatzen ditu.
     */
  
  
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
           
            login frame = new login();
        	frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    } /**
     * Janari motak irakurtzen ditu datu-baseatik eta combo-boxean kargatzen ditu.
     * 
     * @see #taula(janaria)
     */
 // Método que lee los equipos desde la base de datos
    public void irakurriJanaria() {
        try {
            Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
            Statement stmt = konexioa.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM janaria");
          
            while (rs.next()) {
                janaria e = new janaria(
                    rs.getInt("idJanaria"),
                    rs.getString("mota")
                );
                equipoModel.addElement(e);
            }
          
      
          
            rs.close();
            stmt.close();
            konexioa.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar tipos de productos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Produktuen taula betetzen du janari mota jakin batekin.
     * 
     * @param janaria Erakutsiko diren produktuen janari mota
     * @see ImageRenderer
     */
	// Método que carga la lista de jugadores del equipo en la tabla
	public void taula(janaria janaria) {
	    // Defino la consulta SQL para obtener los jugadores del equipo
	    String sql = "SELECT * FROM produktuak WHERE idJanaria = ?";
	    try {
	        // Conecto con la base de datosproduktuak
	        Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
	        PreparedStatement stmt = konexioa.prepareStatement(sql);
	        stmt.setInt(1, janaria.getIdJanaria());  // Establezco el id del equipo

	        // Ejecuto la consulta
	        ResultSet rs = stmt.executeQuery();

	        // Obtengo la metadata de los resultados (columnas)
	        ResultSetMetaData metaDatuak = (ResultSetMetaData) rs.getMetaData();
	        int zutabeKop = metaDatuak.getColumnCount();
	        columnas = new Vector<String>();
	        for (int i = 0; i < zutabeKop; i++) {
	            columnas.add(metaDatuak.getColumnLabel(i + 1).toUpperCase());  // Agrego los nombres de las columnas
	        }

	        datosTabla = new Vector<Vector<String>>();
	        int rowIndex = 0;

	        while (rs.next()) {
	            Vector<String> lerroa = new Vector<String>();

	            // Leer campos normales
	            lerroa.add(rs.getString("produktuKodea"));
	            lerroa.add(""); // Placeholder para imagen
	            lerroa.add(rs.getString("izena"));
	            lerroa.add(rs.getString("marka"));
	            lerroa.add(rs.getString("prezioa"));
	            lerroa.add(rs.getString("data"));
	            lerroa.add(rs.getString("idJanaria"));
	            
	            datosTabla.add(lerroa);

	            // Guardar los bytes de la imagen como propiedad de la tabla con clave por fila
	            byte[] imagenBytes = rs.getBytes("argazkia");
	            taula.putClientProperty("img_" + rowIndex, imagenBytes);
	            rowIndex++;
	        }

	        
	        taulaProduktu.setDataVector(datosTabla, columnas);
	        taula.getColumnModel().getColumn(0).setMinWidth(0);
	        taula.getColumnModel().getColumn(0).setMaxWidth(0);
	        taula.getColumnModel().getColumn(6).setMinWidth(0);
	        taula.getColumnModel().getColumn(6).setMaxWidth(0);
	        
	        rs.close();
	        stmt.close();
	        konexioa.close();  // Cierro la conexión

	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, "Konexio errorea", "Errorea", JOptionPane.ERROR_MESSAGE);  // Manejo de errores de conexión
	    }
	    taula.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());

	    // Actualizo el modelo de datos de la tabla y aplico el ordenamiento
	
	 //   metodoOrdenacion.setModel(dtmTabla);
	

	  
	

	}
	// Renderizador de imágenes mejorado
	class ImageRenderer extends DefaultTableCellRenderer {
	    public ImageRenderer() {
	        setHorizontalAlignment(SwingConstants.CENTER);
	        setOpaque(true);
	    }
	    
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value, 
	            boolean isSelected, boolean hasFocus, int row, int column) {
	        
	        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
	        setText("");
	        setIcon(null);
	        
	        try {
	            byte[] imagenBytes = (byte[]) table.getClientProperty("img_" + row);

	            if (imagenBytes != null && imagenBytes.length > 0) {
	                ImageIcon imageIcon = new ImageIcon(imagenBytes);
	                Image img = imageIcon.getImage();
	                Image newImg = img.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
	                setIcon(new ImageIcon(newImg));
	            } else {
	                setText("(Sin imagen)");
	            }
	        } catch (Exception e) {
	            setText("(Error)");
	        }
	        
	        return this;
	    }
	}
	 /**
     * Produktu bat gordetzen du erabiltzailearen eskaeretan.
     * 
     * @see #getProduktuaFromSelectedRow(int)
     * @see Objetuak.eskaera
     */
	private void guardarProducto() {
	    int filaSeleccionada = taula.getSelectedRow();
	    
	    if (filaSeleccionada < 0) {
	        JOptionPane.showMessageDialog(this, "Lehengo produktu bat aukeratu behar dozu", "Errorea", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    
	    try {
	        // Obtener el producto seleccionado
	        produktua produktua = getProduktuaFromSelectedRow(filaSeleccionada);
	        int kantitatea = Integer.parseInt(textKantitatea.getText());
	        
	        // Validar cantidad
	        if (kantitatea < 1 || kantitatea > 100) {
	            JOptionPane.showMessageDialog(this, "Kantitatea 1 eta 100 artean egon behar da", "Errorea", JOptionPane.WARNING_MESSAGE);
	            return;
	        }
	        
	        // Conexión a la base de datos
	        try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "")) {
	            // Insertar en la tabla eskaera
	            String sql = "INSERT INTO eskaera (idBezero, idProduktua, produktuIzena, produktuMarka, produktuKantitatea) VALUES (?, ?, ?, ?, ?)";
	            
	            try (PreparedStatement pstmt = konexioa.prepareStatement(sql)) {
	                pstmt.setInt(1, bezero.getIdBezero()); // Aquí usamos el ID del bezero que tenemos como campo
	                pstmt.setInt(2, produktua.getProduktuKodea());
	                pstmt.setString(3, produktua.getIzena());
	                pstmt.setString(4, produktua.getMarka());
	                pstmt.setInt(5, kantitatea);
	                
	                int affectedRows = pstmt.executeUpdate();
	                
	                if (affectedRows > 0) {
	                    JOptionPane.showMessageDialog(this, "Produktua ongi gorde da", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
	                    textKantitatea.setText("0"); // Reiniciar contador
	            		writeLog(produktua.getIzena(),  "Produktua saskian ondo gorde da");

	                } else {
	                    JOptionPane.showMessageDialog(this, "Ezin da produktua gorde", "Errorea", JOptionPane.ERROR_MESSAGE);
	                }
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Errorea datu basean gordetxeko: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Kantitatea ez da egokia", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}

	private produktua getProduktuaFromSelectedRow(int filaSeleccionada) {
	    // Obtener datos de la fila seleccionada en la tabla
	    int kodea = Integer.parseInt(taula.getValueAt(filaSeleccionada, 0).toString());
	    String izena = taula.getValueAt(filaSeleccionada, 2).toString();
	    String marka = taula.getValueAt(filaSeleccionada, 3).toString();
	    double prezioa = Double.parseDouble(taula.getValueAt(filaSeleccionada, 4).toString());
	    byte[] argazkia = (byte[]) taula.getClientProperty("img_" + filaSeleccionada);
	    
	    // Crear y devolver el objeto produktua
	    return new produktua(izena, kodea, prezioa, marka, argazkia);
	}
	  /**
     * Produktu baten data eguneratzen du.
     * 
     * @see Objetuak.Data
     */
	private void dataAldatu() {
	    int filaSeleccionada = taula.getSelectedRow();
	

	    if (filaSeleccionada < 0) {
	        JOptionPane.showMessageDialog(this, "Lehengo produktu bat aukeratu behar dozu", "Errorea", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    
	    try {
	        // Obtener los valores de fecha
	        int eguna = Integer.parseInt(txtEguna.getText());
	        int hila = Integer.parseInt(textHilabetea.getText());
	        int urtea = Integer.parseInt(textUrtea.getText());



	        Data nuevaData = new Data(eguna, hila, urtea);
	        String fechaStr = nuevaData.toString(); // Formato "dd/MM/yyyy"
	        
	        // Obtener ID del producto
	        int produktuKodea = Integer.parseInt(taula.getValueAt(filaSeleccionada, 0).toString());
	        //esto se utiliza para el log
	        String produktuIzena = taula.getValueAt(filaSeleccionada, 2).toString();
	        // Conexión a la base de datos
	        try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "")) {
	            String sql = "UPDATE produktuak SET data = ? WHERE produktuKodea = ?";
	            
	            try (PreparedStatement pstmt = konexioa.prepareStatement(sql)) {
	                pstmt.setString(1, fechaStr);
	                pstmt.setInt(2, produktuKodea);
	                
	                int affectedRows = pstmt.executeUpdate();
	                
	                if (affectedRows > 0) {
	                    JOptionPane.showMessageDialog(this, "Data ondo eguneratu da", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
	                    writeLog(produktuIzena, "Produktuaren data ondo eguneratu da");
	                    // Actualizar la tabla para reflejar los cambios
	            		if (!bezero.getPasahitza().equals("admin123")) {

	                    janaria selectedJanaria = (janaria) cmbJanaria.getSelectedItem();
	                    taula(selectedJanaria);
	            		}
	            		if (bezero.getPasahitza().equals("admin123")) {
	            	    janaria selected = equipoModel.getElementAt(currentJanariaIndex);
	                    taula(selected);
	            		}
	                } else {
	                    JOptionPane.showMessageDialog(this, "Ezin da data eguneratu", "Errorea", JOptionPane.ERROR_MESSAGE);
	                }
	            }
	            
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Errorea datu basean gordetxeko: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Mesedez, sartu datak zenbaki gisa", "Error", JOptionPane.ERROR_MESSAGE);
	    }
		if (!bezero.getPasahitza().equals("admin123")) {
	    actualizarTabla();
		}
		if (bezero.getPasahitza().equals("admin123")) {
		actualizarTablaConlaflechita();
		}
	}
	 /**
     * Taula eguneratzen du combo-boxean hautatutako janari motaren arabera.
     */
	private void actualizarTabla() {
	    if (cmbJanaria.getSelectedItem() != null) {
	        janaria selectedJanaria = (janaria) cmbJanaria.getSelectedItem();
	        
	        taula(selectedJanaria);
	        
	    }
	}
	/**
     * Taula eguneratzen du nabigazio-botoiekin hautatutako janari motaren arabera.
     */
	private void actualizarTablaConlaflechita() {
		  if (totalJanariak > 0) {
              janaria selected = equipoModel.getElementAt(currentJanariaIndex);
              taula(selected);
          }
	        
	    }
	 /**
     * Nabigazio-metodoak: lehenengo, aurreko, hurrengo eta azken elementura joateko
     */
	// Métodos para manejar la navegación
	private void iralaPrimerElemento() {
	    if (totalJanariak > 0) {
	        currentJanariaIndex = 0;
	   
	        actualizarLabelJanaria();
	    }
	}

	private void iralaElementoAnterior() {
	    if (totalJanariak > 0) {
	        if (currentJanariaIndex > 0) {
	            currentJanariaIndex--;
	        } else {
	        	   currentJanariaIndex = 0;
	        }
	     
	        actualizarLabelJanaria();
	    }
	}

	private void iralaElementoSiguiente() {
	    if (totalJanariak > 0) {
	        if (currentJanariaIndex < totalJanariak - 1) {
	            currentJanariaIndex++;
	        } else {
	            currentJanariaIndex = totalJanariak - 1;
	        }

	        actualizarLabelJanaria();
	    }
	}

	private void iralaUltimoElemento() {
	    if (totalJanariak > 0) {
	        currentJanariaIndex = totalJanariak - 1;
	     
	        actualizarLabelJanaria();
	    }
	}
	private void actualizarLabelJanaria() {
	    if (totalJanariak > 0 && currentJanariaIndex >= 0 && currentJanariaIndex < totalJanariak) {
	        janaria current = equipoModel.getElementAt(currentJanariaIndex);
	        lblJanariaProduktuak.setText("[" + (currentJanariaIndex + 1) + "/" + totalJanariak + "] " + current.getMota());
	        taula(current); // Actualizar tabla
	    }
	}
	  /**
     * Janari motak irakurtzen ditu eta nabigazio-botoiak aktibatzeko informazioa kargatzen du.
     * 
     * @see #actualizarLabelJanaria()
     */
	// kargal los janaria el el lbl
	public void irakurriJanariakk() {
	    try {
	        Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
	        Statement stmt = konexioa.createStatement();
	        ResultSet rs = stmt.executeQuery("SELECT * FROM janaria");
	        
	        // Limpiar el modelo primero
	        equipoModel.removeAllElements();
	        
	        while (rs.next()) {
	            janaria e = new janaria(
	                rs.getInt("idJanaria"),
	                rs.getString("mota")
	            );
	            equipoModel.addElement(e);
	        }
	        
	        totalJanariak = equipoModel.getSize(); // Guardar el total de elementos
	        if (totalJanariak > 0) {
	            currentJanariaIndex = 0;
	          
	            actualizarLabelJanaria();
	        }
	        
	        rs.close();
	        stmt.close();
	        konexioa.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error al cargar tipos de productos", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	  /**
     * Mezu bat idazten du sistemaren log fitxategian.
     * 
     * @param erabiltzailea Ekintza burutzen duen erabiltzailearen izena
     * @param mezua Ekintzaren deskribapena duen mezua
     */
	public static void writeLog(String erabiltzailea, String mezua) {
		try {
			// Logs-en fitxategia irakurri
			File logFitxategia = new File("logs.txt");
			ArrayList<String> logs = new ArrayList<>();

			// Log fitxategia existitzen bada, irakurtzen dugu
			if (logFitxategia.exists()) {
				try (BufferedReader br = new BufferedReader(new FileReader(logFitxategia))) {
					String line;
					while ((line = br.readLine()) != null) {
						logs.add(line); // Fitxategiko lerro guztiak bildu
					}
				}
			}

			// Log-a sortzen dugu nahi dugun moduan, timestamp-a gehituz
			String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
			String LogBerria = "[" + timestamp + "] (" + erabiltzailea + "): " + mezua;

			// Log berria goikaldean gehitzen dugu (posizio 0-an)
			logs.add(0, LogBerria);

			// Idatzi erregistro guztiak berriro fitxategian, berrienak lehenengo
			try (PrintWriter pw = new PrintWriter(new FileWriter(logFitxategia))) {
				for (String log : logs) {
					pw.println(log); // Fitxategian lerro bakoitza idatzi
				}
			}
		} catch (IOException e) {
			// Errorea gertatuz gero, mezua erakusten da
			JOptionPane.showMessageDialog(null, "Ezin izan da log artxiboan idatzi", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
}

