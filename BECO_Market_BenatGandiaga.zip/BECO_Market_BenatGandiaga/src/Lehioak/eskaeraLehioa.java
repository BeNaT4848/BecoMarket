package Lehioak;


import javax.swing.*; 
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import com.mysql.cj.jdbc.result.ResultSetMetaData;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import Objetuak.bezero;
import Objetuak.eskaera;
import Objetuak.janaria;
import Objetuak.produktua;
import Lehioak.login;

/**
 * eskaeraLehioa klasetik BECO Market aplikazioko eskaerak ikusi eta kudeatzeko leihoa kudeatzen da.
 * Bezeroari lotutako eskaerak bistaratzen dira taula batean.
 * Eskaera bakoitzaren produktuak, kantitateak eta bestelako informazioa agertzen da.
 * Gainera, eskaerak ezabatu eta kantitateak aldatu daitezke.
 * 
 * @author Beñat Ganadiaga
 */
public class eskaeraLehioa extends JFrame {
  
    private bezero bezero;
    private JPanel contentPane;
    private JButton btnSaioaItxi;
    private JLabel lblUserInfo;
    private JLabel lblTitle;
    private JPanel panelProduktuak;
	private DefaultTableModel taulaProduktu;
	private Vector<String> columnas;
	private Vector<Vector<String>> datosTabla;
	private JTable erakeraTaula;
	private JTextField textKantitatea;
	private JTextField textEskaeraKantitatea;
	private JTextField textProduktuKantitatea;

	
	
    public eskaeraLehioa(bezero bezero) {
    	setIconImage(Toolkit.getDefaultToolkit().getImage(eskaeraLehioa.class.getResource("/Irudiak/BECO_Market_Logoa.png")));
        this.bezero = bezero;
        getContentPane().setLayout(null); // Usamos Absolute Layout
    	
        initializeUI();
    
        setupComponents();
        //cargen datos tabla llamas al contrsuct de eskaera y luego a de bezero para saber que idBezero poner
        eskaera esk = new eskaera();
        esk.setIdBezero(bezero.getIdBezero()); // Asumiendo que tienes este método
        taula(esk);
    }
  
    private void initializeUI() {
    	ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
        setTitle("BECO Market - Erosketak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
      
        contentPane = new JPanel();
        contentPane.setLayout(null); // Absolute Layout
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(240, 240, 240));
        setContentPane(contentPane);
    }
  
    private void setupComponents() {
        // Panel superior con información del usuario
        JPanel topPanel = new JPanel();
        topPanel.setLayout(null);
        topPanel.setBounds(10, 10, 800, 64);
        topPanel.setBackground(new Color(56, 118, 29));
        contentPane.add(topPanel);
      
        // Información del usuario
        lblUserInfo = new JLabel("Ongi etorri, " + bezero.getIzena() + " " + bezero.getAbizena());
        lblUserInfo.setBounds(20, 20, 300, 20);
        lblUserInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblUserInfo.setForeground(Color.WHITE);
        topPanel.add(lblUserInfo);
      
        // Título de la aplicación
        lblTitle = new JLabel("BECO Market - Eskaera Sistema");
        lblTitle.setBounds(320, 19, 315, 20);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(lblTitle);
        
        JLabel lblArgazkia = new JLabel("");
        lblArgazkia.setIcon(new ImageIcon(erosketaLehioa.class.getResource("/Irudiak/Carrito.png")));
        lblArgazkia.setBounds(656, 0, 113, 60);
        topPanel.add(lblArgazkia);
      
        // Panel de opción 1: Ver productos
        panelProduktuak = new JPanel();
        panelProduktuak.setLayout(null);
        panelProduktuak.setBounds(10, 73, 766, 399);
        panelProduktuak.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panelProduktuak.setBackground(Color.WHITE);
        panelProduktuak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(panelProduktuak);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane.setBounds(61, 30, 667, 304);
        panelProduktuak.add(scrollPane);
        
      
        
        columnas = new Vector<String>(); // Definimos las columnas de la tabla
        columnas.add("idEskaera");
        columnas.add("idBezero");
        columnas.add("idProduktua");
        columnas.add("IZENA");
        columnas.add("MARKA");
        columnas.add("KANTITATEA");
      

     
   
     
     // Creo el DefaultTableModel para la tabla, utilizando los datos y las columnas
        taulaProduktu = new DefaultTableModel(datosTabla, columnas) {
     		    // Sobrescribo el método isCellEditable para que las celdas no sean editables
     		    @Override
     		    public boolean isCellEditable(int row, int column) {
     		        return false;  // No se pueden editar las celdas
     		        // Si quieres permitir editar una fila específica, puedes hacerlo con:
     		        // return column == el número de la fila
     		    }
     		};
     	   datosTabla = new Vector<Vector<String>>(); // Inicializamos el vector de datos
     	   
     	// En setupComponents(), después de crear el DefaultTableModel:
     	  erakeraTaula = new JTable(taulaProduktu);
     	  erakeraTaula.setForeground(new Color(56, 118, 29));
     		scrollPane.setViewportView(erakeraTaula); // Asignar la tabla al JScrollPane
     		

     		erakeraTaula.getTableHeader().setForeground(new Color(255, 255, 255));
     		erakeraTaula.getTableHeader().setBackground(new Color(56, 118, 29));

     		// Ajustar alto de filas
     		erakeraTaula.setRowHeight(50);
     		
     		textEskaeraKantitatea = new JTextField();
     		textEskaeraKantitatea.setEnabled(false);
     		textEskaeraKantitatea.setEditable(false);
     		textEskaeraKantitatea.setHorizontalAlignment(SwingConstants.CENTER);
     		textEskaeraKantitatea.setForeground(new Color(0, 128, 0));
     		textEskaeraKantitatea.setFont(new Font("Tahoma", Font.BOLD, 16));
     		textEskaeraKantitatea.setText("0");
     		textEskaeraKantitatea.setBounds(272, 359, 96, 27);
     		panelProduktuak.add(textEskaeraKantitatea);
     		textEskaeraKantitatea.setColumns(10);
     		
     		JLabel lblEskaeraKantitatea = new JLabel("Eskaera Kantitatea");
     		lblEskaeraKantitatea.setFont(new Font("Tahoma", Font.BOLD, 18));
     		lblEskaeraKantitatea.setForeground(new Color(0, 128, 0));
     		lblEskaeraKantitatea.setBounds(85, 354, 191, 35);
     		panelProduktuak.add(lblEskaeraKantitatea);
     		
     		JLabel lblProduktuKantitatea = new JLabel("Produktu Kantitatea");
     		lblProduktuKantitatea.setForeground(new Color(0, 128, 0));
     		lblProduktuKantitatea.setFont(new Font("Tahoma", Font.BOLD, 18));
     		lblProduktuKantitatea.setBounds(391, 354, 191, 35);
     		panelProduktuak.add(lblProduktuKantitatea);
     		
     		textProduktuKantitatea = new JTextField();
     		textProduktuKantitatea.setEnabled(false);
     		textProduktuKantitatea.setEditable(false);
     		textProduktuKantitatea.setText("0");
     		textProduktuKantitatea.setHorizontalAlignment(SwingConstants.CENTER);
     		textProduktuKantitatea.setForeground(new Color(0, 128, 0));
     		textProduktuKantitatea.setFont(new Font("Tahoma", Font.BOLD, 16));
     		textProduktuKantitatea.setColumns(10);
     		textProduktuKantitatea.setBounds(605, 359, 96, 27);
     		panelProduktuak.add(textProduktuKantitatea);


     		// Configurar márgenes internos
     		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
     		    @Override
     		    public Component getTableCellRendererComponent(JTable table, Object value, 
     		            boolean isSelected, boolean hasFocus, int row, int column) {
     		        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
     		        setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
     		        return this;
     		    }
     		};


     		for (int i = 0; i < erakeraTaula.getColumnCount(); i++) {
     		    erakeraTaula.getColumnModel().getColumn(i).setCellRenderer(renderer);
     		}


     		// Para que los cambios tengan efecto
     		erakeraTaula.revalidate();
     		erakeraTaula.repaint();
     // En el método setupComponents(), después de crear la tabla JTable:
   
     		  erakeraTaula.addMouseListener(new MouseAdapter() {
     				@Override
     				public void mouseClicked(MouseEvent e) {
     					int errenkada;
     					String kantitatea;
     					errenkada = erakeraTaula.getSelectedRow();
     					kantitatea = (String) erakeraTaula.getValueAt(errenkada, 5);
     					textKantitatea.setText(kantitatea);
     				}
     			});
     	        erakeraTaula.setAutoCreateRowSorter(true);
	  
        btnSaioaItxi = new JButton("Saioa Itxi");
        btnSaioaItxi.setBackground(new Color(56, 118, 29));
        btnSaioaItxi.setForeground(new Color(255, 255, 255));
        btnSaioaItxi.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnSaioaItxi.setBounds(10, 499, 133, 40);
        btnSaioaItxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login login = new login();
				login.setLocationRelativeTo(null);
				login.setVisible(true);
				   writeLog(bezero.getErabiltzailea(), "Saioa itxi dau");
				dispose();
			}
		});
        contentPane.add(btnSaioaItxi);
        
        JButton btnAtzera = new JButton("Atzera");
        btnAtzera.setBackground(new Color(56, 118, 29));
        btnAtzera.setForeground(new Color(255, 255, 255));
        btnAtzera.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		erosketaLehioa erosi = new erosketaLehioa(bezero);
        		erosi.setLocationRelativeTo(null);
        		erosi.setVisible(true);
				dispose();
        	}
        });
        btnAtzera.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnAtzera.setBounds(166, 499, 100, 40);
        contentPane.add(btnAtzera);
        
        JButton btnEzabatuEskaera = new JButton("Eskaera Kendu");
        btnEzabatuEskaera.setBackground(new Color(56, 118, 29));
        btnEzabatuEskaera.setForeground(new Color(255, 255, 255));
        btnEzabatuEskaera.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		eskaeraEzabatu();
        	
        	}
        });
        btnEzabatuEskaera.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnEzabatuEskaera.setBounds(297, 499, 142, 40);
        contentPane.add(btnEzabatuEskaera);
        
        JButton btnKantitateaAldatu = new JButton("Kantitatea Aldatu");
        btnKantitateaAldatu.setForeground(new Color(255, 255, 255));
        btnKantitateaAldatu.setBackground(new Color(56, 118, 29));
        btnKantitateaAldatu.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		kantitateaAldatu();
        	}
        });
        btnKantitateaAldatu.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnKantitateaAldatu.setBounds(460, 499, 159, 40);
        contentPane.add(btnKantitateaAldatu);
        
        textKantitatea = new JTextField();
        textKantitatea.setForeground(new Color(56, 118, 29));
        textKantitatea.setFont(new Font("Tahoma", Font.BOLD, 16));
        textKantitatea.setHorizontalAlignment(SwingConstants.CENTER);
        textKantitatea.setText("0");
        textKantitatea.setBounds(646, 498, 116, 40);
        contentPane.add(textKantitatea);
        textKantitatea.setColumns(10);
        
		
    }
  
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            login frame = new login();
        	frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

	// Método que carga la lista de jugadores del equipo en la tabla
	public void taula(eskaera eskaera) {
	    // Defino la consulta SQL para obtener los jugadores del equipo
	    String sql = "SELECT * FROM eskaera WHERE idBezero = ?";
	    try {
	        // Conecto con la base de datosproduktuak
	        Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
	        PreparedStatement stmt = konexioa.prepareStatement(sql);
	        stmt.setInt(1, bezero.getIdBezero());  

	        // Ejecuto la consulta
	        ResultSet rs = stmt.executeQuery();

	        // Obtengo la metadata de los resultados (columnas)
	        ResultSetMetaData metaDatuak = (ResultSetMetaData) rs.getMetaData();
	        int zutabeKop = metaDatuak.getColumnCount();
	        columnas = new Vector<String>();
	        for (int i = 0; i < zutabeKop; i++) {
	            columnas.add(metaDatuak.getColumnLabel(i + 1).toUpperCase());  // Agrego los nombres de las columnas
	        }

	        datosTabla = new Vector<Vector<String>>();
	      

	        while (rs.next()) {
	            Vector<String> lerroa = new Vector<String>();

	            // Leer campos normales
	            lerroa.add(rs.getString("idEskaera"));
	            lerroa.add(rs.getString("idBezero"));
	            lerroa.add(rs.getString("idProduktua"));
	            lerroa.add(rs.getString("produktuIzena"));
	            lerroa.add(rs.getString("produktuMarka"));
	            lerroa.add(rs.getString("produktuKantitatea"));
	            
	            datosTabla.add(lerroa);

	        }

	        
	        taulaProduktu.setDataVector(datosTabla, columnas);
	        
	        erakeraTaula.getColumnModel().getColumn(0).setMinWidth(0);
	        erakeraTaula.getColumnModel().getColumn(0).setMaxWidth(0);
	        erakeraTaula.getColumnModel().getColumn(1).setMinWidth(0);
	        erakeraTaula.getColumnModel().getColumn(1).setMaxWidth(0);
	        erakeraTaula.getColumnModel().getColumn(2).setMinWidth(0);
	        erakeraTaula.getColumnModel().getColumn(2).setMaxWidth(0);
	        
	        // 1. Primero creamos el renderer por defecto centrado
	 	    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
	 	    centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
	 	    
	 	    // 2. Aplicamos el renderer centrado a TODAS las columnas
	 	    for (int i = 0; i < erakeraTaula.getColumnCount(); i++) {
	 	        erakeraTaula.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
	 	    }
	 	    
	        
	        rs.close();
	        stmt.close();
	        konexioa.close();  // Cierro la conexión

	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, "Konexio errorea", "Errorea", JOptionPane.ERROR_MESSAGE);  // Manejo de errores de conexión
	    }
	    actualizarTotales();
	}
	private void eskaeraEzabatu() {
	    int filaSeleccionada = erakeraTaula.getSelectedRow();
	
	  
	    if (filaSeleccionada == -1) {
	        JOptionPane.showMessageDialog(this, "Mesedez, hautatu ezabatu nahi duzun eskaera", "Abisua", JOptionPane.WARNING_MESSAGE);
	        return;
	    }
	    try {
	        // Obtener el producto seleccionado
	     
	     
	        int idEskaera = Integer.parseInt(erakeraTaula.getValueAt(filaSeleccionada, 0).toString());
	        //Para el log del produktua ezabatu da
	        String Izena = erakeraTaula.getValueAt(filaSeleccionada, 3).toString();
	        // Conexión a la base de datos
	        try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "")) {
	            // Insertar en la tabla eskaera
	            String sql = "DELETE FROM eskaera WHERE idEskaera=  ? ";
	            
	            try (PreparedStatement pstmt = konexioa.prepareStatement(sql)) {
	            	   pstmt.setInt(1, idEskaera);
	             
	           
	                
	                int affectedRows = pstmt.executeUpdate();
	                
	                if (affectedRows > 0) {
	                    JOptionPane.showMessageDialog(this, "Produktua Ezabatu da", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
	                    actualizarTabla();
	                    writeLog(Izena, "Produktua ezabatu da");
	                } 
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Errorea datu basean gordetxeko: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (NumberFormatException ex) {
	        //JOptionPane.showMessageDialog(this, "Kantitatea ez da egokia", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	private void actualizarTabla() {
	    // Limpiar los datos actuales
	    taulaProduktu.setRowCount(0);
	    
	    // Volver a cargar los datos
	    eskaera esk = new eskaera();
	    esk.setIdBezero(bezero.getIdBezero());
	    taula(esk);
	    
	    // Opcional: Asegurar que las columnas ocultas permanecen ocultas
	    erakeraTaula.getColumnModel().getColumn(0).setMinWidth(0);
	    erakeraTaula.getColumnModel().getColumn(0).setMaxWidth(0);
	    erakeraTaula.getColumnModel().getColumn(1).setMinWidth(0);
	    erakeraTaula.getColumnModel().getColumn(1).setMaxWidth(0);
	    erakeraTaula.getColumnModel().getColumn(2).setMinWidth(0);
	    erakeraTaula.getColumnModel().getColumn(2).setMaxWidth(0);
	}
	 
	   public void actualizarTotales() {
	        int size = erakeraTaula.getRowCount();
	        textEskaeraKantitatea.setText("" + size);
	        
	        int produktuKantitatea = 0;
	        for (int i = 0; i < size; i++) {
	            produktuKantitatea += Integer.parseInt(erakeraTaula.getValueAt(i, 5).toString());
	        }
	        
	        textProduktuKantitatea.setText("" + produktuKantitatea);
	      
	    } 
	   private void kantitateaAldatu() {
		    int filaSeleccionada = erakeraTaula.getSelectedRow();
		    
		    if (filaSeleccionada < 0) {
		        JOptionPane.showMessageDialog(this, "Lehengo eskaera bat aukeratu behar dozu", "Errorea", JOptionPane.WARNING_MESSAGE);
		        return;
		    }
		    
		    try {
		        // Obtener el producto seleccionado
		   
		    	int idEskaera = Integer.parseInt(erakeraTaula.getValueAt(filaSeleccionada, 0).toString());
		        String Izenaa = erakeraTaula.getValueAt(filaSeleccionada, 3).toString(); 
		        int kantitatea = Integer.parseInt(textKantitatea.getText());
		        
		        // Validar cantidad
		        if (kantitatea < 1 || kantitatea > 100) {
		            JOptionPane.showMessageDialog(this, "Kantitatea 1 eta 100 artean egon behar da", "Errorea", JOptionPane.WARNING_MESSAGE);
		            return;
		        }
		        
		        // Conexión a la base de datos
		        try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "")) {
		            // Insertar en la tabla eskaera
		        	  String sql = "UPDATE eskaera SET produktuKantitatea = ? WHERE idEskaera = ?";
		            
		            try (PreparedStatement pstmt = konexioa.prepareStatement(sql)) {
		            	  pstmt.setInt(1, kantitatea);
		                  pstmt.setInt(2, idEskaera);
		                
		                int affectedRows = pstmt.executeUpdate();
		                
		                if (affectedRows > 0) {
		                    JOptionPane.showMessageDialog(this, "Produktua ondo eguneratu da ", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
		                    writeLog(Izenaa, "Kantitatea aldatu da ");
		                } else {
		                    JOptionPane.showMessageDialog(this, "Ezin da produktua eguneratu", "Errorea", JOptionPane.ERROR_MESSAGE);
		                }
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(this, "Errorea datu basean gordetxeko: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
		        }
		    } catch (NumberFormatException ex) {
		        JOptionPane.showMessageDialog(this, "Kantitatea ez da egokia", "Error", JOptionPane.ERROR_MESSAGE);
		    }
		    actualizarTotales();
		    actualizarTabla();
		}
		public static void writeLog(String erabiltzailea, String mezua) {
			try {
				// Logs-en fitxategia irakurri
				File logFitxategia = new File("logs.txt");
				ArrayList<String> logs = new ArrayList<>();

				// Log fitxategia existitzen bada, irakurtzen dugu
				if (logFitxategia.exists()) {
					try (BufferedReader br = new BufferedReader(new FileReader(logFitxategia))) {
						String line;
						while ((line = br.readLine()) != null) {
							logs.add(line); // Fitxategiko lerro guztiak bildu
						}
					}
				}

				// Log-a sortzen dugu nahi dugun moduan, timestamp-a gehituz
				String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
				String LogBerria = "[" + timestamp + "] (" + erabiltzailea + "): " + mezua;

				// Log berria goikaldean gehitzen dugu (posizio 0-an)
				logs.add(0, LogBerria);

				// Idatzi erregistro guztiak berriro fitxategian, berrienak lehenengo
				try (PrintWriter pw = new PrintWriter(new FileWriter(logFitxategia))) {
					for (String log : logs) {
						pw.println(log); // Fitxategian lerro bakoitza idatzi
					}
				}
			} catch (IOException e) {
				// Errorea gertatuz gero, mezua erakusten da
				JOptionPane.showMessageDialog(null, "Ezin izan da log artxiboan idatzi", "Errorea", JOptionPane.ERROR_MESSAGE);
			}
		}
 }


