package Lehioak;




import javax.swing.*;  
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.mysql.cj.jdbc.result.ResultSetMetaData;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import Objetuak.Data;
import Objetuak.bezero;
import Objetuak.eskaera;
import Objetuak.janaria;
import Objetuak.produktua;
import Lehioak.login;
import Lehioak.eskaeraLehioa;
import Lehioak.infoProduktua;
public class erabiltzaileLehioa extends JFrame {
  
    private bezero bezero;
    private JPanel contentPane;
    private JButton btnSaioaItxi;
 
    private JLabel lblUserInfo;
    private JLabel lblTitle;
    private JPanel panelProduktuak;

	private JTextField textFiltratuIzena;
	private JTextField textNan;
	private JLabel lblIzenaFiltratu;
	private JLabel lblAdinaEmaitza;
	private JLabel lblInfo;
	
	/**
	 * BECO Market sistemako erabiltzaileen kudeaketarako leiho nagusia.
	 * 
	 * <p>Interfaze grafiko honek honako aukerak ematen ditu:</p>
	 * <ul>
	 *   <li>Erregistratutako erabiltzaileen informazioa ikustea</li>
	 *   <li>Erabiltzaileak izenaren arabera bilatzea</li>
	 *   <li>Erabiltzailearen xehetasunak erakustea (NAN eta adina)</li>
	 *   <li>Saio-itxiera kudeatzea</li>
	 *   <li>Gertaerak log sisteman erregistratzea</li>
	 * </ul>
	 * 
	 * @see Objetuak.bezero
	 * @see Lehioak.login
	 * @see Lehioak.erosketaLehioa
	 * 
	 * @since 1.0
	 */
    public erabiltzaileLehioa(bezero bezero) {
        this.bezero = bezero;
        getContentPane().setLayout(null); // Usamos Absolute Layout
    	
        initializeUI();
        
        setupComponents();
      
    }
  
    private void initializeUI() {
    	ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
        setTitle("BECO Market - Erosketak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
      
        contentPane = new JPanel();
        contentPane.setLayout(null); // Absolute Layout
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(240, 240, 240));
        setContentPane(contentPane);
    }
  
    private void setupComponents() {
        // Panel superior con información del usuario
        JPanel topPanel = new JPanel();
        topPanel.setLayout(null);
        topPanel.setBounds(0, 0, 800, 60);
        topPanel.setBackground(new Color(56, 118, 29));
        contentPane.add(topPanel);
      
        // Información del usuario
        lblUserInfo = new JLabel("Ongi etorri, " + bezero.getIzena() + " " + bezero.getAbizena());
        lblUserInfo.setBounds(20, 20, 300, 20);
        lblUserInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblUserInfo.setForeground(Color.WHITE);
        topPanel.add(lblUserInfo);
      
        // Título de la aplicación
        lblTitle = new JLabel("BECO Market - Erosketa Sistema");
        lblTitle.setBounds(331, 19, 315, 20);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(lblTitle);
        
        JLabel lblArgazkia = new JLabel("");
        lblArgazkia.setIcon(new ImageIcon(erosketaLehioa.class.getResource("/Irudiak/Carrito.png")));
        lblArgazkia.setBounds(656, 0, 113, 60);
        topPanel.add(lblArgazkia);
      
        // Panel de opción 1: Ver productos
        panelProduktuak = new JPanel();
        panelProduktuak.setLayout(null);
        panelProduktuak.setBounds(10, 73, 766, 399);
        panelProduktuak.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panelProduktuak.setBackground(Color.WHITE);
        panelProduktuak.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(panelProduktuak);
        
      lblInfo = new JLabel("Ez dago erabiltzailerik irakurrita");
      lblInfo.setHorizontalAlignment(SwingConstants.CENTER);
        lblInfo.setForeground(new Color(56, 118, 29));
        lblInfo.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblInfo.setBounds(29, 22, 673, 85);
        irakurri();
        panelProduktuak.add(lblInfo);
        
        JButton btnBilatu = new JButton("Bilatu");
        btnBilatu.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		bilatuErabiltzailea();
        	}
        });
        btnBilatu.setBackground(new Color(56, 118, 29));
        btnBilatu.setForeground(new Color(255, 255, 255));
        btnBilatu.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnBilatu.setBounds(541, 127, 151, 58);
        panelProduktuak.add(btnBilatu);
        
        textFiltratuIzena = new JTextField();
        textFiltratuIzena.setForeground(new Color(0, 0, 0));
        textFiltratuIzena.setBounds(283, 138, 213, 44);
        panelProduktuak.add(textFiltratuIzena);
        textFiltratuIzena.setColumns(10);
        
        textNan = new JTextField();
        textNan.setHorizontalAlignment(SwingConstants.CENTER);
        textNan.setForeground(new Color(0, 0, 0));
        textNan.setFont(new Font("Tahoma", Font.BOLD, 20));
        textNan.setEditable(false);
        textNan.setColumns(10);
        textNan.setBounds(138, 271, 213, 58);
        panelProduktuak.add(textNan);
        
        JLabel lblNan = new JLabel("NANA:");
        lblNan.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNan.setForeground(new Color(56, 118, 29));
        lblNan.setBounds(50, 275, 94, 50);
        panelProduktuak.add(lblNan);
        
        JLabel lblAdina = new JLabel("ADINA:");
        lblAdina.setForeground(new Color(56, 118, 29));
        lblAdina.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblAdina.setBounds(382, 282, 71, 36);
        panelProduktuak.add(lblAdina);
        
        lblIzenaFiltratu = new JLabel("Filtratzu izenaren bidez :");
        lblIzenaFiltratu.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblIzenaFiltratu.setForeground(new Color(56, 118, 29));
        lblIzenaFiltratu.setHorizontalAlignment(SwingConstants.CENTER);
        lblIzenaFiltratu.setBounds(10, 138, 236, 36);
        panelProduktuak.add(lblIzenaFiltratu);
        
        lblAdinaEmaitza = new JLabel("0");
        lblAdinaEmaitza.setForeground(new Color(0, 0, 0));
        lblAdinaEmaitza.setFont(new Font("Tahoma", Font.BOLD, 22));
        lblAdinaEmaitza.setHorizontalAlignment(SwingConstants.CENTER);
        lblAdinaEmaitza.setBounds(463, 277, 121, 42);
        panelProduktuak.add(lblAdinaEmaitza);
        
       
	      
        btnSaioaItxi = new JButton("Saioa Itxi");
        btnSaioaItxi.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnSaioaItxi.setForeground(new Color(255, 255, 255));
        btnSaioaItxi.setBackground(new Color(56, 118, 19));
        btnSaioaItxi.setBounds(10, 499, 100, 40);
        btnSaioaItxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login login = new login();
				login.setLocationRelativeTo(null);
				login.setVisible(true);
				   writeLog(bezero.getErabiltzailea(), "Saioa itxi dau");
				dispose();
			}
		});
        contentPane.add(btnSaioaItxi);
    	
        JButton btnAtzera = new JButton("Atzera");
        btnAtzera.setBackground(new Color(56, 118, 29));
        btnAtzera.setForeground(new Color(255, 255, 255));
        btnAtzera.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		erosketaLehioa erosi = new erosketaLehioa(bezero);
        		erosi.setLocationRelativeTo(null);
        		erosi.setVisible(true);
				dispose();
        	}
        });
        btnAtzera.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnAtzera.setBounds(166, 499, 100, 40);
        contentPane.add(btnAtzera);
    }
  
  
  
  
  
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
           
            login frame = new login();
        	frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
 // Método que lee los equipos desde el .dat
  
    /**
     * Erabiltzaileen datuak irakurtzen ditu "erabiltzaileak.dat" fitxategitik.
     * 
     * <p>Interfazean kargatutako erabiltzaile kopurua erakusten du.</p>
     * 
     * @see #bilatuErabiltzailea()
     */
    public void irakurri() {
        File fitxategia = new File("erabiltzaileak.dat");
        ArrayList<bezero> bezeroak = new ArrayList<>();

        if (fitxategia.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fitxategia))) {
                bezeroak = (ArrayList<bezero>) ois.readObject();
                
                // Cambiar el título de la ventana
                lblInfo.setText("Erabiltzaileak irukurri dira (" + bezeroak.size() + " erabiltzaile)");
                
            
                    
            } catch (IOException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Errorea fitxategia irakurtzean: " + ex.getMessage(),
                    "Errorea", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "erabiltzaileak.dat fitxategia ez da existitzen",
                "Errorea", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
   
    /**
     * Erabiltzaile bat bilatzen du izenaren arabera eta bere datuak erakusten ditu (NAN eta adina).
     * 
     * <p>Bilaketa "erabiltzaileak.dat" fitxategian egiten du eta ekintza log sisteman erregistratzen du.</p>
     * 
     * @see #writeLog(String, String)
     * @see #irakurri()
     */
 // Dentro de tu clase erabiltzaileLehioa, añade este método:
    private void bilatuErabiltzailea() {
        String izenaBilatu = textFiltratuIzena.getText().trim();
        writeLog(izenaBilatu, "Erabiltzailearen datuak filtratu dira");
        if (izenaBilatu.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Mesedez, sartu izen bat bilatzeko", 
                "Oharra", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        File fitxategia = new File("erabiltzaileak.dat");
        ArrayList<bezero> bezeroak = new ArrayList<>();
        boolean aurkitua = false;

        if (fitxategia.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fitxategia))) {
                bezeroak = (ArrayList<bezero>) ois.readObject();
                
                for (bezero b : bezeroak) {
                    if (b.getIzena().equalsIgnoreCase(izenaBilatu)) {
                        // Mostrar información del usuario encontrado
                        textNan.setText(b.getNan());
                        lblAdinaEmaitza.setText(String.valueOf(b.getAdina()));
                        aurkitua = true;
                        break;
                    }
                }
                
                if (!aurkitua) {
                    JOptionPane.showMessageDialog(this, 
                        "Ez da erabiltzailerik aurkitu izen horrekin", 
                        "Oharra", 
                        JOptionPane.INFORMATION_MESSAGE);
                    textNan.setText("");
                    lblAdinaEmaitza.setText("0");
                }
                
            } catch (IOException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Errorea fitxategia irakurtzean: " + ex.getMessage(),
                    "Errorea", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "erabiltzaileak.dat fitxategia ez da existitzen",
                "Errorea", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Mezu bat idazten du sistemaren log fitxategian.
     * 
     * <p>Sarrerak timestamp-a, erabiltzaile-izena eta ekintzaren deskribapena ditu.</p>
     * 
     * @param erabiltzailea Ekintza burutzen duen erabiltzailearen izena
     * @param mezua Ekintzaren deskribapena duen mezua
     */
	public static void writeLog(String erabiltzailea, String mezua) {
		try {
			// Logs-en fitxategia irakurri
			File logFitxategia = new File("logs.txt");
			ArrayList<String> logs = new ArrayList<>();

			// Log fitxategia existitzen bada, irakurtzen dugu
			if (logFitxategia.exists()) {
				try (BufferedReader br = new BufferedReader(new FileReader(logFitxategia))) {
					String line;
					while ((line = br.readLine()) != null) {
						logs.add(line); // Fitxategiko lerro guztiak bildu
					}
				}
			}

			// Log-a sortzen dugu nahi dugun moduan, timestamp-a gehituz
			String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
			String LogBerria = "[" + timestamp + "] (" + erabiltzailea + "): " + mezua;

			// Log berria goikaldean gehitzen dugu (posizio 0-an)
			logs.add(0, LogBerria);

			// Idatzi erregistro guztiak berriro fitxategian, berrienak lehenengo
			try (PrintWriter pw = new PrintWriter(new FileWriter(logFitxategia))) {
				for (String log : logs) {
					pw.println(log); // Fitxategian lerro bakoitza idatzi
				}
			}
		} catch (IOException e) {
			// Errorea gertatuz gero, mezua erakusten da
			JOptionPane.showMessageDialog(null, "Ezin izan da log artxiboan idatzi", "Errorea", JOptionPane.ERROR_MESSAGE);
		}
	}
}


