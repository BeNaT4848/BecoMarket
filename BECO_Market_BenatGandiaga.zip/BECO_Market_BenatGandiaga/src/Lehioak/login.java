package Lehioak;



import java.awt.EventQueue; 

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Objetuak.bezero;
import Objetuak.erabiltzaileak;
import Lehioak.Erregistratu;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtErabiltzailea;
	private JPasswordField pwdPasahitza;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Lehio hau programa hasieratzean agertzen dena da (main) eta saioa hasteko da
	 */
	public login() {
		ImageIcon logo = new ImageIcon(getClass().getResource("/Irudiak/BECO_Market_Logoa.png"));
		setIconImage(logo.getImage());
		setTitle("BECO Market");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 584);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblSaioaHasi = new JLabel("Saioa hasi");
		lblSaioaHasi.setForeground(new Color(56, 118, 29));
		lblSaioaHasi.setHorizontalAlignment(SwingConstants.CENTER);
		lblSaioaHasi.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblSaioaHasi.setBounds(75, 176, 185, 41);
		contentPane.add(lblSaioaHasi);

		JLabel lblLogoa = new JLabel("");
		lblLogoa.setIcon(new ImageIcon(login.class.getResource("/Irudiak/BECO_Market_Logoa.png")));
		lblLogoa.setBounds(68, -27, 200, 244);
		contentPane.add(lblLogoa);

		txtErabiltzailea = new JTextField();
		txtErabiltzailea.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtErabiltzailea.getText().equals(" Erabiltzailea")) {
					txtErabiltzailea.setText("");
					txtErabiltzailea.setForeground(Color.BLACK);
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (txtErabiltzailea.getText().isEmpty()) {
					txtErabiltzailea.setText(" Erabiltzailea");
					txtErabiltzailea.setForeground(Color.gray);
				}
			}
		});
		txtErabiltzailea.setForeground(new Color(56, 118, 29));
		txtErabiltzailea.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtErabiltzailea.setText(" Erabiltzailea");
		txtErabiltzailea.setBounds(75, 227, 185, 41);
		contentPane.add(txtErabiltzailea);
		txtErabiltzailea.setColumns(10);

		JButton btnSartu = new JButton("Sartu");
		btnSartu.setBackground(new Color(56, 118, 29));
		btnSartu.setForeground(new Color(255, 255, 255));
		btnSartu.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        sartu(); // Llamar al método sartu()
		    }
		});
		btnSartu.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnSartu.setBounds(75, 343, 185, 41);
		contentPane.add(btnSartu);

		// Hacer que el botón responda al presionar ENTER
		getRootPane().setDefaultButton(btnSartu);
		JButton btnErregistratu = new JButton(" Erregistratu");
		btnErregistratu.setBackground(new Color(56, 118, 29));
		btnErregistratu.setForeground(new Color(255, 255, 255));
		btnErregistratu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Erregistratu erreg = new Erregistratu();
				erreg.setLocationRelativeTo(null);
				erreg.setVisible(true);
				dispose();
			}
		});
		btnErregistratu.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnErregistratu.setBounds(75, 394, 185, 41);
		contentPane.add(btnErregistratu);

		pwdPasahitza = new JPasswordField();
		pwdPasahitza.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (new String(pwdPasahitza.getPassword()).equals(" Pasahitza")) {
					pwdPasahitza.setText("");
					pwdPasahitza.setForeground(Color.BLACK);
					pwdPasahitza.setEchoChar('●'); // Configura asteriscos al escribir
				}
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (new String(pwdPasahitza.getPassword()).isEmpty()) {
					pwdPasahitza.setText(" Pasahitza");
					pwdPasahitza.setForeground(Color.GRAY);
					pwdPasahitza.setEchoChar((char) 0); // Sin asteriscos para el texto por defecto
				}
			}
		});
		pwdPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 15));
		pwdPasahitza.setText(" Pasahitza");
		pwdPasahitza.setEchoChar((char) 0); // Sin asteriscos por defecto
		pwdPasahitza.setForeground(new Color(56, 118, 29));
		pwdPasahitza.setColumns(10);
		pwdPasahitza.setBounds(75, 283, 185, 41);
		contentPane.add(pwdPasahitza);

		SwingUtilities.invokeLater(() -> lblLogoa.requestFocusInWindow());
	}

	/**
	 * Erabiltzailea sartu eta egiaztatzeko metodoa. Erabiltzailea eta pasahitza XML
	 * fitxategian bilatzen dira eta egiaztatzen da datuak zuzenak diren. Datuak
	 * egokiak badira, erabiltzailea hasierako pantailara zuzendu egiten da.
	 * Bestela, errore-mezu bat bistaratzen da.
	 */
	public void sartu() {

		if (loginErabiltzailea(txtErabiltzailea.getText(), new String(pwdPasahitza.getPassword()))!=null) {
			erosketaLehioa home = new erosketaLehioa(loginErabiltzailea(txtErabiltzailea.getText(), new String(pwdPasahitza.getPassword())));
				
			home.setLocationRelativeTo(null);
			home.setVisible(true);
			dispose(); // Leihoaren itxiera
			
		} else {
			JOptionPane.showMessageDialog(null, "Datuak ez dira egokiak edo erabiltzailea ez da existitzen", "Errorea",
					JOptionPane.ERROR_MESSAGE);
		}

	}


	public bezero loginErabiltzailea(String idBezero, String pasahitza) {
	    String sql = "SELECT * FROM bezeroa WHERE erabiltzailea = ? AND pasahitza = ?";

	    try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
	         PreparedStatement stmt = konexioa.prepareStatement(sql)) {

	        stmt.setString(1, idBezero);
	        stmt.setString(2, pasahitza);

	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                return new bezero(
	                    rs.getString("nan"),
	                    rs.getString("izena"),
	                    rs.getString("abizena"),
	                    rs.getInt("adina"),    
	                    rs.getInt("idBezero"),
	                    rs.getString("pasahitza"),
	                    rs.getString("erabiltzailea")
	                );
	                
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;
	}


	public boolean tablaExists(String tableName) {
    String sql = "SHOW TABLES LIKE ?";

    try (Connection konexioa = DriverManager.getConnection("jdbc:mysql://localhost/beco_market", "root", "");
         PreparedStatement stmt = konexioa.prepareStatement(sql)) {

        stmt.setString(1, tableName);

        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next(); // Si hay resultados, la tabla existe
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false; // Si hay error o no hay resultados, la tabla no existe
}
	
}


