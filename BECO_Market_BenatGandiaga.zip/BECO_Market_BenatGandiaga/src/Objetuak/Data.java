package Objetuak;



import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Objects;

import javax.persistence.Embeddable;

@Embeddable
public class Data implements Serializable, Comparable<Data>{

	private static final long serialVersionUID = 202504292L;
	// Defino la clase Fecha
	// Propiedades o Atributos
	private int eguna;
	private int hila;
	private int urtea;
	// Constructor por defecto
	public Data(){
		this.eguna = 1;
		this.hila = 1;
		this.urtea = 2025;
	}
	// Constructor copia
	public Data(Data d){
		this.eguna = d.eguna;
		this.hila = d.hila;
		this.urtea = d.urtea;	
	}
	
	// Constructor personalizado
	public Data(int e, int h, int u){
		// controlo errores
		if(e >= 1 && e <= 31) {
			this.eguna = e;
		}
		if(h >= 1 && h <= 12) {
			this.hila = h;
		}
		if(u != 0) {
			this.urtea = u;
		}
	}
	
	public Data(String katea){
		// creo una fecha a partir de un String con formato dd/MM/yyyy
		try {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
      LocalDate fecha = LocalDate.parse(katea, formatter);
      
      eguna = fecha.getDayOfMonth();
      hila = fecha.getMonthValue(); // Los meses van de 1 a 12
      urtea = fecha.getYear();
		} catch (DateTimeParseException e) {
      System.out.println("Data formatu ez egokia");
		}
	}
	
	// Getters and Setters
	public int getDia() {
		return eguna;
	}
	public void setDia(int eguna) {
		// controlo errores
		if(eguna >= 1 && eguna <= 31) {
			this.eguna = eguna;
		}
	}
	public int getHila() {
		return hila;
	}
	public void setHila(int hila) {
		// controlo errores
		if(hila >= 1 && hila <= 12) {
			this.hila = hila;
		}
	}
	public int getUrtea() {
		return urtea;
	}
	public void setUrtea(int urtea) {
		// controlo errores
		if(urtea != 0) {
			this.urtea = urtea;
		}
	}
	// toString
	@Override
	public String toString() {
		return (eguna + "/" + hila + "/" + urtea);
	}
	
	// hashCode
	@Override
	public int hashCode() {
		return Objects.hash(urtea, eguna, hila);
	}
	
	// equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			// si son el mismo objeto
			return true;
		if (obj == null)
			// si obj no esta creado
			return false;
		if (getClass() != obj.getClass())
			// si son de distinta clase
			return false;
		// comparo las propiedades
		Data other = (Data) obj;
		return (urtea == other.urtea && eguna == other.eguna && hila == other.hila);
	}
	
	// compareTo
	@Override
	public int compareTo(Data other) {
		// comparo las propiedades
		int konparaketa = 0;
		// comparo año
		if (this.urtea < other.urtea) {
			konparaketa = -1;
		}
		else if (this.urtea > other.urtea) {
			konparaketa = 1;
		}
		else {
			// si año es igual
			// comparo mes
			if (this.hila < other.hila) {
				konparaketa = -1;
			}
			else if (this.hila > other.hila) {
				konparaketa = 1;
			}
			else {
				// si mes es igual
				// comparo dia
				if (this.eguna < other.eguna) {
					konparaketa = -1;
				}
				else if (this.eguna > other.eguna) {
					konparaketa = 1;
				}
			}
		}
		// devuelvo el resultado de la comparacion
		return konparaketa;
	}
	
	/**
	 * Versión alternativa que utiliza el constructor de la clase para validar
	 */
	
	
}

