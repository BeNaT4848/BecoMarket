package Objetuak;



import java.util.Objects;

public class erabiltzaileak extends pertsona {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String erabiltzailea;
	private String pasahitza;


	public erabiltzaileak() {
		this.erabiltzailea = "";
		this.pasahitza = "";
		
	}

	public erabiltzaileak(String erabiltzailea, String pasahitza) {
		super.setNan("");
		super.setIzena("");
		super.setAbizena("");
		super.setAdina(0);
		this.erabiltzailea = erabiltzailea;
		this.pasahitza = pasahitza;
	
	}

	public erabiltzaileak(String izena, String abizena, String nan, int adina, String erabiltzailea, String pasahitza) {
		super.setNan(nan);
		super.setIzena(izena);
		super.setAbizena(abizena);
		super.setAdina(adina);
		this.erabiltzailea = erabiltzailea;
		this.pasahitza = pasahitza;
	

	}
	
	

	@Override
	public String toString() {
		return "<erabiltzaile>\n<izena>" + super.getIzena() + "</izena>\n<abizena>" + super.getAbizena()
				+ "</abizena>\n<nan>" + super.getNan() + "</nan>\n<adina>" + super.getAdina() + "</adina>\n<erabiltzailea>"
				+ this.erabiltzailea + "</erabiltzailea>\n<pasahitza>" + this.pasahitza + "</pasahitza>\\n</erabiltzaile>";
	}

	

	@Override
	public int hashCode() {
	    return Objects.hash(erabiltzailea);
	}

	@Override
	public boolean equals(Object obj) {
	    if (this == obj) return true;
	    if (obj == null || getClass() != obj.getClass()) return false;
	    erabiltzaileak other = (erabiltzaileak) obj;
	    return Objects.equals(erabiltzailea, other.erabiltzailea);
	}


	public String getErabiltzailea() {
		return erabiltzailea;
	}

	public void setErabiltzailea(String erabiltzailea) {
		this.erabiltzailea = erabiltzailea;
	}

	public String getPasahitza() {
		return pasahitza;
	}

	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}

}
