package Objetuak;



import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Lob;

@Entity
public class bezero extends pertsona implements Serializable {
	private static final long serialVersionUID = 1L;

	@Lob
	private int idBezero;
	private String pasahitza;
	private String erabiltzailea;
	

	public bezero() {
		this.idBezero=0;
		this.pasahitza="";
		this.erabiltzailea="";
	}

	public bezero(int idBezero, String pasahitza, String erabiltzailea) {
		this.idBezero=idBezero;
		this.pasahitza=pasahitza;
		this.erabiltzailea=erabiltzailea;
		
	}
	public bezero(String nan, String izena, String abizena, int adina,String erabiltzailea,String pasahitza) {
		super.setNan(nan);
		super.setIzena(izena);
		super.setAbizena(abizena);
		super.setAdina(adina);
		this.erabiltzailea=erabiltzailea;
		this.pasahitza=pasahitza;
		
	
	}
	public bezero(String nan, String izena, String abizena, int adina,int idBezero,String pasahitza,String erabiltzailea) {
		super.setNan(nan);
		super.setIzena(izena);
		super.setAbizena(abizena);
		super.setAdina(adina);
		this.idBezero=idBezero;
		this.pasahitza=pasahitza;
		this.erabiltzailea=erabiltzailea;
	
	}

	


	/**
	 * @return the pasahitza
	 */
	public String getPasahitza() {
		return pasahitza;
	}

	/**
	 * @param pasahitza the pasahitza to set
	 */
	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}

	/**
	 * @return the idBezero
	 */
	public int getIdBezero() {
		return this.idBezero;
	}

	/**
	 * @return the erabiltzailea
	 */
	public String getErabiltzailea() {
		return erabiltzailea;
	}

	/**
	 * @param erabiltzailea the erabiltzailea to set
	 */
	public void setErabiltzailea(String erabiltzailea) {
		this.erabiltzailea = erabiltzailea;
	}

	/**
	 * @param idBezero the idBezero to set
	 */
	public void setIdBezero(int idBezero) {
		this.idBezero = idBezero;
	}

	@Override
	public String toString() {
		return "" + this.getIzena() + " " + this.getAbizena() + " "  + this.getAdina() + "";
	}

	public String idatziBez() {
		return "<bezero>\n<bezIzena>" + getIzena() + "</bezIzena>\n<abizena>" + getAbizena() + "</abizena>\n<nan>"
				+ getNan() + "</nan>\n<adina>" + getAdina() + "</adina>\n</bezero>\n";
	}

}
