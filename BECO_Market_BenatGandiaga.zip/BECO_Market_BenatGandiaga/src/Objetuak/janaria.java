package Objetuak;


import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class janaria implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int IdJanaria;
	private String mota;
	


	public janaria() {
		this.IdJanaria = 0;
		this.mota = "";
		
	}

	public janaria(int idJanaria, String mota) {
		this.IdJanaria = idJanaria;
		this.mota = mota;
	}
	public janaria(janaria j) {
		this.IdJanaria = j.IdJanaria;
		this.mota = j.mota;
	}
	/**
	 * @return the idJanaria
	 */
	public int getIdJanaria() {
		return IdJanaria;
	}

	/**
	 * @param idJanaria the idJanaria to set
	 */
	public void setIdJanaria(int idJanaria) {
		IdJanaria = idJanaria;
	}

	/**
	 * @return the mota
	 */
	public String getMota() {
		return mota;
	}

	/**
	 * @param mota the mota to set
	 */
	public void setMota(String mota) {
		this.mota = mota;
	}

	@Override
	public int hashCode() {
		return Objects.hash(IdJanaria);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof janaria)) {
			return false;
		}
		janaria other = (janaria) obj;
		return IdJanaria == other.IdJanaria;
	}

	@Override
	public String toString() {
	    return this.getMota(); // O el atributo correcto para mostrar
	}
	

}
