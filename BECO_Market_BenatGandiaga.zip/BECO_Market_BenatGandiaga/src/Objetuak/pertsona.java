package Objetuak;


import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class pertsona implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String nan;
	private String izena;
	private String abizena;
	private int adina;

	public pertsona() {
		this.nan = "";
		this.izena = "";
		this.abizena = "";
		this.adina = 0;
	}

	public pertsona(String nan, String izena, String abizena, int adina) {
		this.nan = nan;
		this.izena = izena;
		this.abizena = abizena;
		this.adina = adina;
	}

	public String getNan() {
		return nan;
	}

	public void setNan(String nan) {
		this.nan = nan;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getAbizena() {
		return abizena;
	}

	public void setAbizena(String abizena) {
		this.abizena = abizena;
	}

	public int getAdina() {
		return adina;
	}

	public void setAdina(int adina) {
		this.adina = adina;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nan);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		pertsona other = (pertsona) obj;
		return Objects.equals(nan, other.nan);
	}
}
