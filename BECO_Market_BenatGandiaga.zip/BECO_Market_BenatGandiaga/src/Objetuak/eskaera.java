package Objetuak;


import java.io.Serializable;
import java.util.Objects;

public class eskaera implements Serializable, Cloneable {
    private static final long serialVersionUID = 1L;
    
    private int kantitatea;
    private int eskaeraKodea;
    private int idBezero;// Cambiado a minúscula inicial por convención
    private String produktuIzena;
    private String produktuMarka;
    private int idProduktu;
    
    // Constructor
    public eskaera( int eskaeraKodea,int idBezero,int idProduktu, String produktuIzena, String produktuMarka,int kantitatea) {
        this.kantitatea = kantitatea;
        this.eskaeraKodea = eskaeraKodea;
        this.idBezero=idBezero;
        this.idProduktu=idProduktu;
        this.produktuIzena=produktuIzena;
        this.produktuMarka=produktuMarka;
    }
    public eskaera() {
        kantitatea= 0;
        eskaeraKodea=0;
        idBezero=0;
        produktuIzena="";
        produktuMarka="";
        idProduktu= 0;
    }
    
    
    /**
	 * @return the idBezero
	 */
	public int getIdBezero() {
		return this.idBezero;
	}
	/**
	 * @param idBezero the idBezero to set
	 */
	public void setIdBezero(int idBezero) {
		this.idBezero = idBezero;
	}
	// Getters y setters
    public int getKantitatea() {
        return kantitatea;
    }
    
    public void setKantitatea(int kantitatea) {
        this.kantitatea = kantitatea;
    }
    
    public int getEskaeraKodea() {
        return eskaeraKodea;
    }
    
    public void setEskaeraKodea(int eskaeraKodea) {
        this.eskaeraKodea = eskaeraKodea;
    }
    
    /**
	 * @return the produktuIzena
	 */
	public String getProduktuIzena() {
		return produktuIzena;
	}
	/**
	 * @param produktuIzena the produktuIzena to set
	 */
	public void setProduktuIzena(String produktuIzena) {
		this.produktuIzena = produktuIzena;
	}
	/**
	 * @return the produktuMarka
	 */
	public String getProduktuMarka() {
		return produktuMarka;
	}
	/**
	 * @param produktuMarka the produktuMarka to set
	 */
	public void setProduktuMarka(String produktuMarka) {
		this.produktuMarka = produktuMarka;
	}
	/**
	 * @return the idEskaera
	 */
	public int getidProduktu() {
		return idProduktu;
	}
	/**
	 * @param idEskaera the idEskaera to set
	 */
	public void setidProduktu(int idProduktu) {
		this.idProduktu = idProduktu;
	}
	// Método equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        eskaera eskaera = (eskaera) o;
        return kantitatea == eskaera.kantitatea &&
               eskaeraKodea == eskaera.eskaeraKodea;
    }
    
    // Método hashCode
    @Override
    public int hashCode() {
        return Objects.hash(kantitatea, eskaeraKodea);
    }
    
 
}