package Objetuak;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import Objetuak.Data;
@Entity
public class produktua implements Serializable,  Comparable<produktua> {
    private static final long serialVersionUID = 2L;  // Diferente al de Eskaera
    private String izena;
    @Id
    private int produktuKodea;
    private double prezioa;
    private String marka;
    private  String argazkiaa;
	@Lob
    private byte[] argazkia;
	 @Temporal(TemporalType.DATE)
    private Date data;
	private int idJanaria;
	
    // Constructor
    public produktua() {
        this.izena = "";
        this.produktuKodea = 0;
        this.prezioa = 0;
        this.marka = "";
    	this.argazkia=null;
    	this.idJanaria=0;
    }
    
    public produktua(String izena, int produktuKodea, double prezioa, String marka,byte[] argazkia) {
    	super();
        this.izena = izena;
        this.produktuKodea = produktuKodea;
        this.prezioa = prezioa;
        this.marka = marka;
    	this.argazkia=argazkia;
    }
    public produktua(int IdJanaria,Data d, String izena, int produktuKodea, double prezioa, String marka,byte[] argazkia) {
    	super();
        this.izena = izena;
        this.produktuKodea = produktuKodea;
        this.prezioa = prezioa;
        this.marka = marka;
    	this.argazkia=argazkia;
    }
    public produktua( int produktuKodea, int idJanaria,byte[] argazkia, String izena,String marka,double prezioa ) {
    	super();
        this.izena = izena;
        this.produktuKodea = produktuKodea;
        this.prezioa = prezioa;
        this.marka = marka;
    	this.argazkia=argazkia;
    	this.idJanaria=idJanaria;
    }
    public produktua(produktua p) {
    	this.produktuKodea = p.produktuKodea;
    	this.argazkia = p.argazkia;
    	this.izena = p.izena;
    	this.marka = p.marka;
    	this.prezioa =p.prezioa;
    	this.data = p.data;
    	this.idJanaria = p.idJanaria;
    	}
    public produktua(int produktuKodea, String argazkiaa, String izena, String marka,
    		double prezioa, Date data, int idJanaria) {
        this.produktuKodea = produktuKodea;
        this.argazkiaa = argazkiaa;
        this.izena = izena;
        this.marka = marka;
        this.prezioa = prezioa;
        this.data = data;
        this.idJanaria = idJanaria;
    }
    // Getters y setters
    public String getIzena() {
        return izena;
    }
    
    public void setIzena(String izena) {
        this.izena = izena;
    }
    
    public int getProduktuKodea() {
        return produktuKodea;
    }
    
    public void setProduktuKodea(int produktuKodea) {
        this.produktuKodea = produktuKodea;
    }
    
    public double getPrezioa() {
        return prezioa;
    }
    
    public void setPrezioa(double prezioa) {
        this.prezioa = prezioa;
    }
    
    public String getMarka() {
        return marka;
    }
    
    public void setMarka(String marka) {
        this.marka = marka;
    }
	public byte[] getArgazkia() {
		return argazkia;
	}

	public void setArgazkia(byte[] argazkia) {
		this.argazkia = argazkia;
	}

    /**
	 * @return the idJanaria
	 */
	public int getIdJanaria() {
		return idJanaria;
	}

	/**
	 * @param idJanaria the idJanaria to set
	 */
	public void setIdJanaria(int idJanaria) {
		this.idJanaria = idJanaria;
	}

	/**
	 * @return the argazkiaa
	 */
	public String getArgazkiaa() {
		return argazkiaa;
	}

	/**
	 * @param argazkiaa the argazkiaa to set
	 */
	public void setArgazkiaa(String argazkiaa) {
		this.argazkiaa = argazkiaa;
	}

	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}

	// Método equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        produktua produktua = (produktua) o;
        return produktuKodea == produktua.produktuKodea &&
               prezioa == produktua.prezioa &&
               Objects.equals(izena, produktua.izena) &&
               Objects.equals(marka, produktua.marka);
    }
    
    // Método hashCode
    @Override
    public int hashCode() {
        return Objects.hash(izena, produktuKodea, prezioa, marka);
    }
 
    

    // Método adicional para mostrar precio formateado (opcional)
    public String getPrezioaFormateatua() {
        return String.format("%d €", prezioa);
    }
	@Override
	public int compareTo(produktua p) {
	    // 1. aurrekontua descendente
	    int result = Double.compare(p.prezioa, this.prezioa);
	    if (result != 0) return result;

	    // 2. fundazioa ascendente
	    result = this.getData().compareTo(p.getData());
	    /* if (result != 0) */ return result;

	    // 3. idSailak descendente
	  //  return Double.compare(p.idJanaria ,this.idJanaria);
	}

}